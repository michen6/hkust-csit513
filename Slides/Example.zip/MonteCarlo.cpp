//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains command code used to run a Monte Carlo simulation
// on a workbook that contains the appropriate named ranges.
//============================================================================
//============================================================================
#include <windows.h>
#include <math.h>

#include "XllNames.h"

//============================================================
// This command calculates the active worksheet and records
// the average value of a named range Payoff, depositing this
// in a named range AvgPayoff.
//============================================================
int __stdcall monte_carlo_control(void)
{
	double payoff, sum_payoff = 0.0, sum_sq_payoff = 0.0;
	double std_dev;
	cpp_xloper Break, CalcSetting(3); // Manual recalculation

	Excel4(xlfCancelKey, 0, 1, p_xlTrue); // Enable user breaks
	Excel4(xlfEcho, 0, 1, p_xlFalse); // Disable screen updating
	Excel4(xlcCalculation, 0, 1, &CalcSetting); // Manual

	long trials, max_trials, dont_do_screen, refresh_count;

// Set up references to named ranges which must exist
	xlName MaxTrials("!MaxTrials"), Payoff("!Payoff"), AvgPayoff("!AvgPayoff");

// Set up references to named ranges whose existence is optional
	xlName Trials("!Trials"), StdDev("!StdDev"), StdErr("!StdErr"), RefreshCount("!RefreshCount");

	if(!MaxTrials.IsRefValid() || !Payoff.IsRefValid()
	|| !AvgPayoff.IsRefValid())
		goto cleanup;

	if(!RefreshCount.IsRefValid())
		refresh_count = 1000;
	else
		refresh_count = (long)(double)RefreshCount;

	dont_do_screen = refresh_count;

	max_trials = (long)(double)MaxTrials;

	for(trials = 1; trials <= max_trials; trials++)
	{
		Excel4(xlcCalculateDocument, 0, 0);

		payoff = (double)Payoff;

		sum_payoff += payoff;
		sum_sq_payoff += payoff * payoff;

		if(!--dont_do_screen)
		{
			std_dev = sqrt(sum_sq_payoff - sum_payoff * sum_payoff
				/ trials) / (trials - 1);
 
			Excel4(xlfEcho, 0, 1, p_xlTrue);

			AvgPayoff = sum_payoff / trials;
			Trials = (double)trials;
			StdDev = std_dev;
			StdErr = std_dev / sqrt((double)trials);

			Excel4(xlfEcho, 0, 1, p_xlFalse);
			dont_do_screen = refresh_count;

// Detect and clear any user break attempt
			Excel4(xlAbort, &Break, 1, p_xlFalse);

			if((bool)Break)
				goto cleanup;
		}
	}

cleanup:
	CalcSetting = 1; // Automatic recalculation
	Excel4(xlfEcho, 0, 1, p_xlTrue);
	Excel4(xlcCalculation, 0, 1, &CalcSetting);
	return 1;
}

