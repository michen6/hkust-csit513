//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
#ifndef __XLL_ADDIN
#define __XLL_ADDIN

#ifndef _CPP_XLOPER_H
#include "cpp_xloper.h"
#endif

#define NUM_COMMANDS		12
#define NUM_FUNCTIONS		73
#define MAX_EXCEL4_ARGS		30

// Used to register DLL functions
extern char *FunctionExports[NUM_FUNCTIONS][MAX_EXCEL4_ARGS - 1];
extern char *CommandExports[NUM_COMMANDS][2];

// These are displayed by the Excel add-in manager
extern char *AddinVersionStr;
extern char *AddinName;


// Enumeration of the columns of a custom C API dialog box

enum
{
	CAPI_DLG_ITEM,
	CAPI_DLG_HPOS,
	CAPI_DLG_VPOS,
	CAPI_DLG_WIDTH,
	CAPI_DLG_HEIGHT,
	CAPI_DLG_TEXT,
	CAPI_DLG_VALUE,
	CAPI_DLG_COLUMNS,
};

bool called_from_paste_fn_dlg(void);

#endif
