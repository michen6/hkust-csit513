//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples relating to the use of the COM from
// within a DLL to access Excel's functionality.
//============================================================================
//============================================================================
#include <windows.h>
#include <comdef.h>
#include <stdio.h>

#include "XllAddIn.h"

IDispatch *pExcelDisp = NULL;

//================================================================
bool InitExcelOLE(void)
{
	if(pExcelDisp)
		return true; // already initialised

// Make sure Excel is registered in the Running Object Table. Even
// if it already has, telling it to do so again will do no harm.
	HWND hWnd;
	if((hWnd = FindWindow("XLMAIN", 0)) != NULL)
	{
// Sending WM_USER + 18 tells Excel to register itself in the ROT
		SendMessage(hWnd, WM_USER + 18, 0, 0);
	}

// Initialise the COM library for this compartment
	OleInitialize(NULL);

	CLSID clsid;
	HRESULT hr;
	char cErr[64];
	IUnknown *pUnk;

	hr = CLSIDFromProgID(L"Excel.Application", &clsid);

	if(FAILED(hr))
	{
// This is unlikely unless you have forgotten to call OleInitialize
		sprintf(cErr, "Error, hr = 0x%08lx", hr);
		MessageBox(NULL, cErr, "CLSIDFromProgID",
					MB_OK | MB_SETFOREGROUND);
		return false;
	}

	hr = GetActiveObject(clsid, NULL, &pUnk);

	if(FAILED(hr))
	{
// Excel may not have registered itself in the ROT
		sprintf(cErr, "Error, hr = 0x%08lx", hr);
    	MessageBox(NULL, cErr, "GetActiveObject",
					MB_OK | MB_SETFOREGROUND);
		return false;
	}

	hr = pUnk->QueryInterface(IID_IDispatch,(void**)&pExcelDisp);

	if(FAILED(hr))
	{
		sprintf(cErr, "Error, hr = 0x%08lx", hr);
    	MessageBox(NULL, cErr, "QueryInterface",
					MB_OK | MB_SETFOREGROUND);
		return false;
	}
// We no longer need pUnk
	pUnk->Release();

// We have now done everything necessary to be able to access all of
// the methods and properties of the Excel.Application interface.
	return true;
}
//================================================================
void UninitExcelOLE(void)
{
// Release the IDispatch pointer. This will decrement its RefCount
	pExcelDisp->Release();
	pExcelDisp = NULL; // Good practice
	OleUninitialize();
}
//================================================================
HRESULT OLE_ExcelCalculate(void)
{
	if(!pExcelDisp)
		return S_FALSE;

	static DISPID dispid = 0;
	DISPPARAMS Params;
	char cErr[64];
	HRESULT hr;

// DISPPARAMS has four members which should all be initialised
	Params.rgdispidNamedArgs = NULL; // Dispatch IDs of named args
	Params.rgvarg = NULL; // Array of arguments
	Params.cArgs = 0; // Number of arguments
	Params.cNamedArgs = 0; // Number of named arguments

// Get the Calculate method's dispid
	if(dispid == 0) // first call to this function
	{
// GetIDsOfNames will only be called once. Dispid is cached since it
// is a static variable. Subsequent calls will be faster

		wchar_t *ucName = L"Calculate";
		hr = pExcelDisp->GetIDsOfNames(IID_NULL, &ucName, 1,
						LOCALE_SYSTEM_DEFAULT, &dispid);

		if(FAILED(hr))
		{
// Perhaps VBA command or function does not exist
			sprintf(cErr, "Error, hr = 0x%08lx", hr);
    		MessageBox(NULL, cErr, "GetIDsOfNames",
				MB_OK | MB_SETFOREGROUND);
			return hr;
		}
	}

// Call the Calculate method
	hr = pExcelDisp->Invoke(dispid, IID_NULL, LOCALE_SYSTEM_DEFAULT,
			DISPATCH_METHOD, &Params, NULL, NULL, NULL);

	if(FAILED(hr))
	{
// Most likely reason to get an error is because of an error in a
// UDF that makes a COM call to Excel or some other automation
// interface
		sprintf(cErr, "Error, hr = 0x%08lx", hr);
    	MessageBox(NULL, cErr, "Calculate", MB_OK | MB_SETFOREGROUND);
	}
	return hr; // = S_OK if successful
}
//================================================================
#define MAX_COM_CMD_LEN		512

HRESULT OLE_RunXllCommand(char *cmd_name)
{
	static DISPID dispid = 0;
	VARIANTARG Command;
	DISPPARAMS Params;
	HRESULT hr;
	wchar_t w[MAX_COM_CMD_LEN + 1];
	char cErr[64];
	int cmd_len = strlen(cmd_name);

	if(!pExcelDisp || !cmd_name || !*cmd_name
	|| (cmd_len = strlen(cmd_name)) > MAX_COM_CMD_LEN)
		return S_FALSE;

	try
	{
// Convert the byte string into a wide char string.  A simple C-style
// type cast would not work!
		mbstowcs(w, cmd_name, cmd_len + 1);

		Command.vt = VT_BSTR;
		Command.bstrVal = SysAllocString(w);

		Params.rgdispidNamedArgs = NULL;
		Params.rgvarg = &Command;
		Params.cArgs = 1;
		Params.cNamedArgs = 0;

		if(dispid == 0)
		{
			wchar_t *ucName = L"Run";
			hr = pExcelDisp->GetIDsOfNames(IID_NULL, &ucName, 1,
				LOCALE_SYSTEM_DEFAULT, &dispid);

			if (FAILED(hr))
			{
				sprintf(cErr, "Error, hr = 0x%08lx", hr);
    			MessageBox(NULL, cErr, "GetIDsOfNames",
					MB_OK|MB_SETFOREGROUND);

				SysFreeString(Command.bstrVal);
				return hr;
			}
		}

		hr = pExcelDisp->Invoke(dispid,IID_NULL,LOCALE_SYSTEM_DEFAULT,
				DISPATCH_METHOD, &Params, NULL, NULL, NULL);

		if(FAILED(hr))
		{
			sprintf(cErr, "Error, hr = 0x%08lx", hr);
    		MessageBox(NULL, cErr, "Invoke",
				MB_OK | MB_SETFOREGROUND);

			SysFreeString(Command.bstrVal);
			return hr;
		}
		// Success.
	}
	catch (_com_error &ce)
	{
// If COM throws an exception, we end up here. Most probably we will
// get a useful description of the error.

		MessageBoxW(NULL, ce.Description(), L"Run",
			MB_OK | MB_SETFOREGROUND);

// Get and display the error code in case the message wasn't helpful
		hr = ce.Error();

		sprintf(cErr, "Error, hr = 0x%08lx", hr);
    	MessageBox(NULL, cErr, "The Error code",
			MB_OK|MB_SETFOREGROUND);
	}
	SysFreeString(Command.bstrVal);
	return hr;
}
//================================================================
// Run a registered XLL function.  The name of the function is the
// 1st element of ArgArray, and NumArgs is 1 + the number of args
// the the XLL function takes.  Function can only take and return
// types that are Excel's supported Variants.
//================================================================
HRESULT OLE_RunXllFunction(VARIANT &RetVal, int NumArgs, VARIANTARG *ArgArray)
{
	if(!pExcelDisp)
		return S_FALSE;

	static DISPID dispid = 0;
	DISPPARAMS Params;
	HRESULT hr;

	Params.cArgs = NumArgs;
	Params.rgvarg = ArgArray;
	Params.cNamedArgs = 0;

	if(dispid == 0)
	{
		wchar_t *ucName = L"Run";
		hr = pExcelDisp->GetIDsOfNames(IID_NULL, &ucName, 1,
			LOCALE_SYSTEM_DEFAULT, &dispid);

		if(hr != S_OK)
			return hr;
	}

	if(dispid)
	{
		VariantInit(&RetVal);
		hr = pExcelDisp->Invoke(dispid, IID_NULL,
			LOCALE_SYSTEM_DEFAULT, DISPATCH_METHOD, &Params,
			&RetVal, NULL, NULL);
	}
	return hr;
}
//================================================================
#define MAX_COM_EXPR_LEN		1024

HRESULT CallVBAEvaluate(char *expr, VARIANT &RetVal)
{
	static DISPID dispid = 0;
	VARIANTARG String;
	DISPPARAMS Params;
	HRESULT hr;
	wchar_t w[MAX_COM_EXPR_LEN + 1];
	char cErr[64];
	int expr_len;

	if(!pExcelDisp || !expr || !*expr
	|| (expr_len = strlen(expr)) > MAX_COM_EXPR_LEN)
		return S_FALSE;

	try
	{
		VariantInit(&String);

// Convert the byte string into a wide char string
		mbstowcs(w, expr, expr_len + 1);

		String.vt = VT_BSTR;
		String.bstrVal = SysAllocString(w);

		Params.rgdispidNamedArgs = NULL;
		Params.rgvarg = &String;
		Params.cArgs = 1;
		Params.cNamedArgs = 0;

		if(dispid == 0)
		{
			wchar_t *ucName = L"Evaluate";
			hr = pExcelDisp->GetIDsOfNames(IID_NULL, &ucName, 1,
				LOCALE_SYSTEM_DEFAULT, &dispid);

			if(FAILED(hr))
			{
				sprintf(cErr, "Error, hr = 0x%08lx", hr);
				MessageBox(NULL, cErr, "GetIDsOfNames",
					MB_OK | MB_SETFOREGROUND);

				SysFreeString(String.bstrVal);
				return hr;
			}
		}

// Initialise the VARIANT that receives the return value, if any.
// If we don't care we can pass NULL to Invoke instead of &RetVal
		VariantInit(&RetVal);

		hr = pExcelDisp->Invoke(dispid,IID_NULL,LOCALE_SYSTEM_DEFAULT,
		DISPATCH_METHOD, &Params, &RetVal, NULL, NULL);

		if(FAILED(hr))
		{
			sprintf(cErr, "Error, hr = 0x%08lx", hr);
			MessageBox(NULL, cErr, "Invoke",
				MB_OK | MB_SETFOREGROUND);
			SysFreeString(String.bstrVal);
			return hr;
		}
		// Success. 
	}
	catch(_com_error &ce)
	{
// If COM throws an exception, we end up here. Most probably we will
// get a useful description of the error.  You can force arrival in
// this block by passing a division by zero in the string

		MessageBoxW(NULL, ce.Description(), L"Evaluate",
			MB_OK | MB_SETFOREGROUND);

// Get and display the error code in case the message wasn't helpful
		hr = ce.Error();

		sprintf(cErr, "Error, hr = 0x%08lx", hr);
		MessageBox(NULL, cErr, "The error code",
			MB_OK | MB_SETFOREGROUND);
	}
	SysFreeString(String.bstrVal);
	return hr;
}
