//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains functions that create cubic splines and
// interpolate them.  For licensing reasons the key passages of code are
// omitted.  (See comments in the code).  The file also contains a simple
// linear interpolation function.
//============================================================================
//============================================================================
#include <windows.h>

#include "XllAddIn.h"

#define SPLINE_GRAD_START_FIXED		0x01
#define SPLINE_GRAD_END_FIXED		0x02

//======================================================================================
xloper * __stdcall make_spline(xl_array *input, double grad_start, double grad_end, int mode)
{
	WORD rows = input->rows, cols = input->columns;

	if(cols != 2 || rows < 2)
		return p_xlErrValue;

	double *array = input->array;
	double *x = (double *)calloc(4 * rows, sizeof(double));
	double *y = x + rows, *u = y + rows, *y2 = u + rows;
	int i, index;

// Input is expected to be in 2 columns: x-vals then y-vals
	for(index = i = 0; i < rows;)
	{
		x[i] = array[index++];
		y[i++] = array[index++];
	}

// For licensing reasons the code here is omitted.  See Numerical
// Recipes in C and Numerical Recipes in C++ (Cambridge Press),
// Section 3.3 for the function spline(...) which can be called
// from here with suitable conversion of arguments.  The result
// of calling this function is a vector of 2nd derivatives of
// y w.r.t. x, called y2[].  This is returned to the caller
// in an xloper of type xltypeMulti as a single column.

	cpp_xloper RetVal(rows, (WORD)1, y2);
	free(x); // can't free this till finished with y2[]
	return RetVal.ExtractXloper();
}
//============================================================
xloper * __stdcall spline_interp(double x, xl_array *input, xloper *pBlend)
{
	double blend;

// Blend is used to scale the 2nd derivatives.  This is most
// efficiently done in the last step of the cubic interpolation
// where the entire term that relates to these can be factored
// by this amount.  When 0, the effect is to produce straight
// line interpolation between points, and when 1, a normal
// cubic spline.
	if(!coerce_to_double(pBlend, blend) || blend < 0.0 || blend > 1.0)
		blend = 1.0;

	WORD rows = input->rows, cols = input->columns;

// Check the dimensions of the input array and then
// transpose the input (supplied as 3 columns: x-vals, y-vals
// d2y/dx2 vals) to ease access to the data in rows.
	if(cols != 3 || rows < 2 || transpose_xl_array(input) == false)
		return p_xlErrValue;

	double *xa = input->array;
	double *ya = input->array + rows;
	double *y2a = input->array + 2 * rows;
	double y = 0.0; // safe default given missing code below

// For licensing reasons the code here is omitted.  See Numerical
// Recipes in C and Numerical Recipes in C++ (Cambridge Press),
// Section 3.3 for the function splint(...) which can be called
// from here with suitable conversion of arguments.  The result
// of calling this function is a value y, returned to the caller
// in an xloper of type xltypeNum.

	cpp_xloper RetVal(y);
	return RetVal.ExtractXloper();
}
//=================================================================================
xloper * __stdcall interp(double x, xl_array *yy, xl_array *xx, int dont_extrapolate)
{
// Check that input ranges are same size and shape
	if(yy->columns != xx->columns || yy->rows != xx->rows)
		return p_xlErrValue;

	int low = 0, high, i;
	static xloper ret_val = {0.0, xltypeNum};

// Check that input is either a row or column and get the size
	if(yy->rows == 1)
		high = yy->columns - 1;
	else if(yy->columns == 1)
		high = yy->rows - 1;
	else
		return p_xlErrValue;

	if(high == 0)
	{
		ret_val.val.num = yy->array[0];
		return &ret_val;
	}

	if(x < xx->array[0] || x > xx->array[high])
	{
		if(dont_extrapolate)
			return p_xlErrNum;

		ret_val.val.num = yy->array[x < xx->array[0] ? 0 : high];
		return &ret_val;
	}

	while(high - low > 1)
	{
		if(xx->array[i = (high + low) >> 1] > x)
			high = i;
		else
			low = i;
	}

	ret_val.val.num = yy->array[low] + (x - xx->array[low]) *
		(yy->array[high] - yy->array[low]) / (xx->array[high] - xx->array[low]);

	return &ret_val;
}
