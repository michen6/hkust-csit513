//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains functions used to time the performance of
// compiled C/C++ code.  This is used to test the relative performance
// compared to VBA.
//============================================================================
//============================================================================
#include <windows.h>
#include <math.h>

#include "XllAddIn.h"

double __stdcall get_time_C(short trigger);

//===========================================
double __stdcall C_call_test(double d)
{
	return d;
}
//===========================================
bool __stdcall C_test0(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			; // do nothing

	return true;
}
//===========================================
double __stdcall C_timed_test0(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test0(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
long __stdcall C_test1(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	long v;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v = 1;

	return v;
}
//===========================================
double __stdcall  C_timed_test1(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test1(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall  C_test2(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v = 1.5;

	return v;
}
//===========================================
double __stdcall  C_timed_test2(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test2(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
long __stdcall C_test3(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	long v1 = 3;
	long v2;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v2 = v1;

	return v2;
}
//===========================================
double __stdcall  C_timed_test3(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test3(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall C_test4(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v1 = 3.5;
	double v2;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v2 = v1;

	return v2;
}
//===========================================
double __stdcall  C_timed_test4(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test4(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall C_test5(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v = 1.1;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v *= 1.0000001;

	return v;
}
//===========================================
double __stdcall  C_timed_test5(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test5(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall C_test6(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v = exp(1.5);

	return v;
}
//===========================================
double __stdcall  C_timed_test6(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test6(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall C_test7(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v1 = 3.3;
	double v2;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v2 = v1 * (v1 * (v1 * (v1 + 1.1) + 2.2) + 3.3) + 4.4;

	return v2;
}
//===========================================
double __stdcall  C_timed_test7(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test7(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
double __stdcall C_test8(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	double v1;
	double v2[10];

    v2[0] = 1.1;
    v2[1] = 2.2;
    v2[2] = 3.3;
    v2[3] = 4.4;
    v2[4] = 5.5;
    v2[5] = 6.6;
    v2[6] = 7.7;
    v2[7] = 8.8;
    v2[8] = 9.9;
    v2[9] = 10.1;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			v1 = v2[0] + v2[1] + v2[2] + v2[3] + v2[4] + v2[5] + v2[6] + v2[7] + v2[8] + v2[9];

	return v1;
}
//===========================================
double __stdcall  C_timed_test8(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test8(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
bool __stdcall C_test9(long trigger, long inner_loops, long outer_loops, long array_size)
{
	long i;
	long j;
	double *dynamic_array;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
		{
			dynamic_array = (double *)malloc(array_size * sizeof(double));
			free(dynamic_array);
		}

	return true;
}
//===========================================
double __stdcall  C_timed_test9(long trigger, long inner_loops, long outer_loops, long array_size)
{
	double t;

	t = get_time_C(0);

	C_test9(0, inner_loops, outer_loops, array_size);

	return get_time_C(0) - t;
}
//===========================================
bool test_function(bool arg)
{
	return arg;
}
//===========================================
bool __stdcall C_test10(long trigger, long inner_loops, long outer_loops)
{
	long i;
	long j;
	bool b = true;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
		{
			b = test_function(b);
		}

	return b;
}
//===========================================
double __stdcall  C_timed_test10(long trigger, long inner_loops, long outer_loops)
{
	double t;

	t = get_time_C(0);

	C_test10(0, inner_loops, outer_loops);

	return get_time_C(0) - t;
}
//===========================================
long __stdcall C_test11(long trigger, long inner_loops, long outer_loops, LPSTR test_string)
{
	long i;
	long j;
	long sum;
	char *p;

	for(i = 0; ++i <= outer_loops; )
		for(j = 0; ++j <= inner_loops;)
			for(sum = 0, p = test_string; *p; sum += *p++);

	return true;
}
//===========================================
double __stdcall C_timed_test11(long trigger, long inner_loops, long outer_loops, LPSTR test_string)
{
	double t;

	t = get_time_C(0);

	C_test11(0, inner_loops, outer_loops, test_string);

	return get_time_C(0) - t;
}
//===========================================
