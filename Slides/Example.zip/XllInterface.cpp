//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains the functions that Excel's Add-in Manager looks
// for as part of the XLL interface to the DLL's functionality.  It contains
// the code that registers the DLL's functions and commands and cleans-up when
// the XLL is being closed.  It contains the function called by Excel to free
// DLL-allocated memory for things that were returned to it by the DLL during
// worksheet function calls.
//============================================================================
//============================================================================
#include <windows.h>
#include <stdio.h>

#include "XllAddIn.h"
#include "Background.h"

void customise_Excel_UI(bool set_up);
bool InitExcelOLE(void);
void UninitExcelOLE(void);

// Internal name list management function: cleans the list
int __stdcall delete_all_xll_names(void);

bool xll_initialised = false;

#define USE_CPP_XLOPER 1

//========================================================================
#define CLASS_NAME_BUFFER_SIZE    50

typedef struct
{
	BOOL is_paste_fn;
	short low_hwnd;
}
	fnwiz_enum_struct;

//------------------------------------------------------------------------
// The callback function called by Windows for every top-level window
BOOL __stdcall fnwiz_enum_proc(HWND hwnd, fnwiz_enum_struct *p_enum)
{
// Check if the parent window is Excel
	if(LOWORD((DWORD)GetParent(hwnd)) != p_enum->low_hwnd)
		return TRUE; // keep iterating

	char class_name[CLASS_NAME_BUFFER_SIZE + 1];
//	Ensure that class_name is always null terminated
	class_name[CLASS_NAME_BUFFER_SIZE] = 0;

	GetClassName(hwnd, class_name, CLASS_NAME_BUFFER_SIZE);

//	Do a case-insensitve comparison for the Paste Function window
//	class name with the Excel version number truncated
	if(_strnicmp(class_name, "bosa_sdm_xl", 11) == 0)
	{
		p_enum->is_paste_fn = TRUE;
		return FALSE;  // Tells Windows to stop iterating
	}
	return TRUE; // Tells Windows to continue iterating
}
//------------------------------------------------------------------------
bool called_from_paste_fn_dlg(void)
{
	xloper hwnd = {0.0, xltypeNil}; // super-safe

	if(Excel4(xlGetHwnd, &hwnd, 0))
//	Can't get Excel's main window handle, so assume not
		return false;

	fnwiz_enum_struct es = {FALSE, hwnd.val.w};
	EnumWindows((WNDENUMPROC)fnwiz_enum_proc, (LPARAM)&es);

	return es.is_paste_fn == TRUE;
}
//========================================================================
typedef struct
{
	short main_xl_handle;
	HWND full_handle;
}
	get_hwnd_enum_struct;

//------------------------------------------------------------------------
// The callback function called by Windows for every top-level window
BOOL __stdcall get_hwnd_enum_proc(HWND hwnd, get_hwnd_enum_struct *p_enum)
{
// Check if the low word of the handle matches Excel's
	if(LOWORD((DWORD)hwnd) != p_enum->main_xl_handle)
		return TRUE; // keep iterating

	char class_name[CLASS_NAME_BUFFER_SIZE + 1];
//	Ensure that class_name is always null terminated
	class_name[CLASS_NAME_BUFFER_SIZE] = 0;

	GetClassName(hwnd, class_name, CLASS_NAME_BUFFER_SIZE);

//	Do a case-insensitve comparison for Excel's main window
//	class name
	if(_stricmp(class_name, "xlmain") == 0)
	{
		p_enum->full_handle = hwnd;
		return FALSE;  // Tells Windows to stop iterating
	}
	return TRUE; // Tells Windows to continue iterating
}
//------------------------------------------------------------------------
HWND get_xl_main_handle(void)
{
	xloper main_xl_handle = {0.0, xltypeNil}; // safe initialisation

	if(Excel4(xlGetHwnd, &main_xl_handle, 0))
		return 0;

	get_hwnd_enum_struct eproc_param = {main_xl_handle.val.w, 0};
	EnumWindows((WNDENUMPROC)get_hwnd_enum_proc, (LPARAM)&eproc_param);
	return eproc_param.full_handle;
}
//========================================================================
#if USE_CPP_XLOPER

void display_register_error(char *fn_name, int XL4_err_num, int err_num)
{
	char temp_buffer[256];
	sprintf(temp_buffer, "Could not register function %s (XL4:%d,Err:%d)", fn_name, XL4_err_num, err_num);

	cpp_xloper xStr(temp_buffer);
	cpp_xloper xInt(2); // Dialog box type.

	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);
}

#else

void display_register_error(char *fn_name, int XL4_err_num, int err_num)
{
	char temp_buffer[256];
	sprintf(temp_buffer, "Could not register function %s (XL4:%d,Err:%d)", fn_name, XL4_err_num, err_num);

	xloper xStr;
	xloper xInt;

	xStr.xltype = xltypeStr;
	xInt.xltype = xltypeInt;

	xStr.val.str = new_xlstring(temp_buffer);
	xInt.val.w = 2;

	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);

	free(xStr.val.str);
}
#endif
//========================================================================
#if !USE_CPP_XLOPER

xloper *register_function(int fn_index)
{
	xloper fn_args[MAX_EXCEL4_ARGS - 1];
	xloper *ptr_array[MAX_EXCEL4_ARGS - 1 + 1];

//-------------------------------------------------------
// default to this values in case of a problem
//-------------------------------------------------------
	static xloper RetVal = *p_xlErrValue;

//-------------------------------------------------------
// Get the full path and name of the DLL.
// Passed as the first argument to xlfRegister, so need
// to set first pointer in array to point to this.
//-------------------------------------------------------
	xloper dll_name = {0.0, xltypeNil};

	if(Excel4(xlGetName, &dll_name, 0) != xlretSuccess)
	{
		Excel4(xlFree, 0, 1, &dll_name);  // shouldn't need to do this
		return NULL;
	}

	ptr_array[0] = &dll_name;
	int num_args = 1;

//-------------------------------------------------------
// Set up the rest of the array of pointers.
//-------------------------------------------------------
	for(int i = 0; i < MAX_EXCEL4_ARGS - 1; i++)
		fn_args[i].xltype = 0;

	char *p_arg;
	for(i = 0; i < MAX_EXCEL4_ARGS - 1; i++)
	{
		// get the next string for the char * array
		if((p_arg = FunctionExports[fn_index][i]) == NULL)
			break;

		// Set the corresponding xlfRegister argument
		fn_args[i].xltype = xltypeStr;
		fn_args[i].val.str = new_xlstring(p_arg);
		ptr_array[num_args++] = fn_args + i;
	}

//-------------------------------------------------------
// Need at least 6 DLL function args (7 args in total for
// the call to xlfRegister including the DLL name), before
// calling Excel4v(xlfRegister, ...) to register the function.
//-------------------------------------------------------
	int xl4_retval;

	if(num_args < 7
	|| (xl4_retval = Excel4v(xlfRegister, &RetVal, num_args, ptr_array)) != xlretSuccess
	|| RetVal.xltype == xltypeErr)
	{
		display_register_error(FunctionExports[fn_index][0], xl4_retval, RetVal.val.err);
	}
	Excel4(xlFree, 0, 1, &RetVal); // shouldn't be necessary

	for(i = 0; i < MAX_EXCEL4_ARGS - 1; i++)
		if(fn_args[i].xltype == xltypeStr)
			free(fn_args[i].val.str);

	Excel4(xlFree, 0, 1, &dll_name);
	RetVal.xltype |= xlbitXLFree;
	return &RetVal;
}

#else // #if USE_CPP_XLOPER

xloper *register_function(int fn_index)
{
	xloper *ptr_array[MAX_EXCEL4_ARGS];

//-------------------------------------------------------
// default to this value in case of a problem
//-------------------------------------------------------
	cpp_xloper RetVal((WORD)xlerrValue);

//-------------------------------------------------------
// Get the full path and name of the DLL.
// Passed as the first argument to xlfRegister, so need
// to set first pointer in array to point to this.
//-------------------------------------------------------
	cpp_xloper DllName;

	if(Excel4(xlGetName, &DllName, 0) != xlretSuccess)
		return NULL;

// Tell destructor to use Excel to free memory
	DllName.SetExceltoFree();
	ptr_array[0] = &DllName;

//-------------------------------------------------------
// Set up the rest of the array of pointers.
//-------------------------------------------------------
	cpp_xloper *fn_args = new cpp_xloper[MAX_EXCEL4_ARGS];

	char *p_arg;
	int i = 0, num_args = 1;

	do
	{
		// get the next string from the char * array
		if((p_arg = FunctionExports[fn_index][i]) == NULL)
			break;

		// Set the corresponding xlfRegister argument
		fn_args[i] = p_arg; // create 
		ptr_array[num_args++] = &(fn_args[i++]); // & operater overloaded to return &xloper
	}
	while(num_args < MAX_EXCEL4_ARGS);

	int xl4_retval = Excel4v(xlfRegister, &RetVal, num_args, ptr_array);

	if(xl4_retval != xlretSuccess || RetVal.GetType() == xltypeErr)
	{
		display_register_error(FunctionExports[fn_index][0], xl4_retval, (int)RetVal);
	}

	delete[] fn_args;
	return RetVal.ExtractXloper(false);
}

#endif

//========================================================================
xloper *register_command(char *code_name, char *Excel_name)
{
//-------------------------------------------------------
// default to this value in case of a problem
//-------------------------------------------------------
	cpp_xloper RetVal((WORD)xlerrValue);

//-------------------------------------------------------
// Get the full path and name of the DLL.
// Passed as the first argument to xlfRegister, so need
// to set first pointer in array to point to this.
//-------------------------------------------------------
	cpp_xloper DllName;

	if(Excel4(xlGetName, &DllName, 0) != xlretSuccess)
	{
		DllName.Free(true); // don't really need to do this, but...
		return NULL;
	}
	DllName.SetExceltoFree();

//-------------------------------------------------------
// Set up the rest of the arguments.
//-------------------------------------------------------
	cpp_xloper CodeName(code_name);
	cpp_xloper ExcelName(Excel_name);
	cpp_xloper RtnType("J");
	cpp_xloper FnType(2); // Command

	int xl4_retval = Excel4(xlfRegister, &RetVal, 6, &DllName,
		&CodeName, &RtnType, &ExcelName, p_xlNil, &FnType);

	if(xl4_retval != xlretSuccess || RetVal.IsType(xltypeErr))
		display_register_error(code_name, xl4_retval, (int)RetVal);

// Err or Num: no need to free, but no harm in doing it anyway
	return RetVal.ExtractXloper(true);
}
//========================================================================
bool unregister_function(int fn_index)
{
// Decrement the usage count for the function
//	int xl4 = Excel4(xlfUnregister, 0, 1, register_ID + fn_index);

// Get the name that Excel associates with the function
	cpp_xloper xStr(FunctionExports[fn_index][2]);

// Undo the association of the name with the resource
	int xl4 = Excel4(xlfSetName, 0 , 1, &xStr);

	if(xl4 != xlretSuccess)
		return false;

	return true;
}
//========================================================================
bool unregister_command(int cmd_index)
{
// Decrement the usage count for the function
//	int xl4 = Excel4(xlfUnregister, 0, 1, register_ID + cmd_index);

// Get the name that Excel associates with the function
	cpp_xloper xStr(CommandExports[cmd_index][2]);

// Undo the association of the name with the resource
	int xl4 = Excel4(xlfSetName, 0 , 1, &xStr);

	if(xl4 != xlretSuccess)
		return false;

	return true;
}
//========================================================================
int __stdcall xlAutoOpen(void)
{
	if(xll_initialised)
		return 1;

// Register the functions
	for(int i = 0 ; i < NUM_FUNCTIONS; i++)
		register_function(i);
//		register_ID[i] = *(register_function(i));

	for(int i = 0 ; i < NUM_COMMANDS; i++)
		register_command(CommandExports[i][0], CommandExports[i][1]);

// Setup any custom menus, event traps, etc.
	customise_Excel_UI(true);

// Initialise the COM interface and the Excel IDispatch object
	InitExcelOLE();

// Initialise the background thread in the TaskList class
	ExampleTaskList.CreateTaskThread();

	xll_initialised = true;
	return 1;
}
//========================================================================
int __stdcall xlAutoClose(void)
{
	if(!xll_initialised)
		return 1;

// Unregister the functions and commands
	for(int i = 0 ; i < NUM_FUNCTIONS; i++)
		unregister_function(i);

	for(int i = 0 ; i < NUM_COMMANDS; i++)
		unregister_command(i);

// Remove the custom menus, event traps, etc.
	customise_Excel_UI(false);

// Un-initialse the Com interface and free the associated objects
	UninitExcelOLE();

// Shut down the background thread in the TaskList class
	ExampleTaskList.DeleteTaskThread();

// Delete all DLL-internal names including those created
// via instances of the xlName class
	delete_all_xll_names();

	xll_initialised = false;
	return 1;
}
//========================================================================
xloper * __stdcall xlAutoRegister(xloper *pxName)
{
	char *p;
//	xloper *p_op;

// Look for the given function name in our list of functions
	for(int i = 0 ; i < NUM_FUNCTIONS; i++)
	{
		p = FunctionExports[i][0];

		if(p && _stricmp(pxName->val.str, p) == 0)
		{
//			p_op = register_function(i);
//			register_ID[i] = *p_op;
//			return p_op;
			return register_function(i);
		}
	}

	for(int i = 0 ; i < NUM_COMMANDS; i++)
	{
		p = CommandExports[i][0];

		if(p && _stricmp(pxName->val.str, p) == 0)
			register_command(p, CommandExports[i][1]);
	}

	return NULL;
}
//========================================================================
#if !USE_CPP_XLOPER

xloper * __stdcall xlAddInManagerInfo(xloper *p_arg)
{
	if(!xll_initialised)
		xlAutoOpen();

	static xloper ret_oper;

	ret_oper.xltype = xltypeErr;
	ret_oper.val.err = xlerrValue;

	if(p_arg == NULL)
		return &ret_oper;
	
	if((p_arg->xltype == xltypeNum && p_arg->val.num == 1.0)
	|| (p_arg->xltype == xltypeInt && p_arg->val.w == 1))
	{
// Return a dynamically allocated byte-counted string and tell Excel
// to call back into the DLL to free it once Excel has finished.
		ret_oper.xltype = xltypeStr | xlbitDLLFree;
		ret_oper.val.str = new_xlstring(AddinName);
	}
	return &ret_oper;
}

#else

xloper * __stdcall xlAddInManagerInfo(xloper *p_arg)
{
	if(!xll_initialised)
		xlAutoOpen();

	cpp_xloper Arg(p_arg);
	cpp_xloper RetVal;

	if(Arg == 1)
		RetVal = AddinName;
	else
		RetVal = (WORD)xlerrValue;

	return RetVal.ExtractXloper();
}

#endif

//========================================================================
void __stdcall xlAutoFree(xloper *p_oper)
{
	if(p_oper->xltype & xltypeMulti)
	{
// Check if the elements need to be freed then check if the array
// itself needs to be freed.
		int size = p_oper->val.array.rows * p_oper->val.array.columns;
		xloper *p = p_oper->val.array.lparray;

		for(; size-- > 0; p++)
			if(p->xltype & (xlbitDLLFree | xlbitXLFree))
				xlAutoFree(p);

		if(p_oper->xltype & xlbitDLLFree)
			free(p_oper->val.array.lparray);
	}
	else if(p_oper->xltype == (xltypeStr | xlbitDLLFree))
	{
		free(p_oper->val.str);
	}
	else if(p_oper->xltype == (xltypeRef | xlbitDLLFree))
	{
		free(p_oper->val.mref.lpmref);
	}
	else if(p_oper->xltype | xlbitXLFree)
	{
		Excel4(xlFree, 0, 1, p_oper);
	}
}
//========================================================================
#if USE_CPP_XLOPER

int __stdcall xlAutoAdd(void)
{
	if(!xll_initialised)
		xlAutoOpen();

	cpp_xloper xStr(AddinVersionStr);
	cpp_xloper xInt(2); // Dialog box type.
	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);
	return 1;
}

#else

int __stdcall xlAutoAdd(void)
{
	if(!xll_initialised)
		xlAutoOpen();

	xloper xStr;
	xloper xInt;

	xStr.xltype = xltypeStr;
	xInt.xltype = xltypeInt;

	xStr.val.str = new_xlstring(AddinVersionStr);
	xInt.val.w = 2; // Dialog box type.
	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);
	free(xStr.val.str);
	return 1;
}
#endif

//========================================================================
#if USE_CPP_XLOPER

int __stdcall xlAutoRemove(void)
{
	cpp_xloper xStr("Add-in has been removed");
	cpp_xloper xInt(2); // Dialog box type.
	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);
	return 1;
}

#else

int __stdcall xlAutoRemove(void)
{
	xloper xStr, xInt;

	xStr.xltype = xltypeStr;
	xStr.val.str = new_xlstring("Add-in has been removed");

	xInt.xltype = xltypeInt;
	xInt.val.w = 2; // Dialog box type.

	Excel4(xlcAlert, NULL, 2, &xStr, &xInt);

// Free memory allocated by new_xlstring()
	free(xStr.val.str);

	return 1;
}

#endif
//========================================================================
__declspec(dllexport) bool __stdcall DllMain(HINSTANCE hDll, DWORD Reason, void *Reserved)
{
// This function gets called when the DLL is first loaded and when detached.
// Neither the C API nor COM should be called from this function.

	switch (Reason)
	{
		case DLL_PROCESS_ATTACH:
			return TRUE;

		case DLL_PROCESS_DETACH:
			return TRUE;
	}
	return TRUE;
}
