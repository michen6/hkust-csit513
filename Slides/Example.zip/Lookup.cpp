//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples that extend the functionality of
// functions such as MATCH, COUNTIF and SUMIF to accommodate more match
// criteria.
//============================================================================
//============================================================================
#include <windows.h>
#include "XllAddIn.h"

//=================================================================
xloper * __stdcall match_multi(
		xloper *value1, xloper *range1,
		xloper *value2, xloper *range2,
		xloper *value3, xloper *range3,
		xloper *value4, xloper *range4,
		xloper *value5, xloper *range5)
{
// Get the arguments into a more managable form.
// Arguments are registered as opers so that range references are
// already converted to xltypeMulti.
	cpp_xloper args[5][2] = {{value1, range1}, {value2, range2}, {value3, range3}, {value4, range4}, {value5, range5}};

// Find the last non-missing value/range pair
	int num_searches = 0;

	do
	{
		if(args[num_searches][0].IsType(xltypeMissing | xltypeErr)
		|| !args[num_searches][1].IsType(xltypeMulti))
			break;
	}
	while(++num_searches < 5);

	if(!num_searches)
		return p_xlErrValue;

// Check that all the input arrays are the same shape and size
	WORD rows, columns;
	WORD temp_rows, temp_columns;

	args[0][1].GetArraySize(rows, columns);

// Check that input is either single row or single column
	if(rows != 1 && columns != 1)
		return p_xlErrValue;

	for(int i = 1; i < num_searches; i++)
	{
		args[i][1].GetArraySize(temp_rows, temp_columns);

		if(rows != temp_rows || columns != temp_columns)
			return p_xlErrValue;
	}

	DWORD limit = rows * columns;
	DWORD offset;

// Simple search does not assume search ranges are sorted and
// looks for an exact match
	for(offset = 0; offset < limit; offset++)
	{
		int i;
		for(i = 0; i < num_searches; i++)
			if(args[i][0] != args[i][1].GetArrayElement(offset))
				break;

		if(i == num_searches) // Match found!
		{
		// Increment the offset as INDEX() counts from 1
			cpp_xloper RetVal((double)(offset + 1));
			return RetVal.ExtractXloper();
		}
	}
	return p_xlErrNa;
}
//=================================================================
xloper * __stdcall sum_if_multi(xloper *sum_range,
		xloper *value1, xloper *range1,
		xloper *value2, xloper *range2,
		xloper *value3, xloper *range3,
		xloper *value4, xloper *range4,
		xloper *value5, xloper *range5)
{
// Get the arguments into a more managable form.
// Arguments are registered as opers so that range references are
// already converted to xltypeMulti.
	cpp_xloper SumRange(sum_range);
	cpp_xloper args[5][2] = {{value1, range1}, {value2, range2}, {value3, range3}, {value4, range4}, {value5, range5}};

	if(!SumRange.IsType(xltypeMulti))
		return p_xlErrValue;

// Find the last non-missing value/range pair
	int num_searches = 0;

	do
	{
		if(args[num_searches][0].IsType(xltypeMissing | xltypeErr) 
		|| !args[num_searches][1].IsType(xltypeMulti))
			break;
	}
	while(++num_searches < 5);

	if(!num_searches)
		return p_xlErrValue;

// Check that all the input arrays are the same shape and size
	WORD rows, columns;
	WORD temp_rows, temp_columns;

	SumRange.GetArraySize(rows, columns);

// Check that input is either single row or single column
	if(rows != 1 && columns != 1)
		return p_xlErrValue;

	for(int i = 0; i < num_searches; i++)
	{
		args[i][1].GetArraySize(temp_rows, temp_columns);

		if(rows != temp_rows || columns != temp_columns)
			return p_xlErrValue;
	}

	DWORD limit = rows * columns;
	DWORD offset;
	double temp, sum = 0.0;

// Simple search does not assume search ranges are sorted and
// looks for an exact match
	for(offset = 0; offset < limit; offset++)
	{
		int i;
		for(i = 0; i < num_searches; i++)
			if(args[i][0] != args[i][1].GetArrayElement(offset))
				break;

		if(i == num_searches && SumRange.GetArrayElement(offset, temp))
			sum += temp;
	}
	cpp_xloper RetVal(sum);
	return RetVal.ExtractXloper();
}
//=================================================================
xloper * __stdcall count_if_multi(
		xloper *value1, xloper *range1,
		xloper *value2, xloper *range2,
		xloper *value3, xloper *range3,
		xloper *value4, xloper *range4,
		xloper *value5, xloper *range5)
{
// Get the arguments into a more managable form.
// Arguments are registered as opers so that range references are
// already converted to xltypeMulti.
	cpp_xloper args[5][2] = {{value1, range1}, {value2, range2}, {value3, range3}, {value4, range4}, {value5, range5}};

// Find the last non-missing value/range pair
	int num_searches = 0;

	do
	{
		if(args[num_searches][0].IsType(xltypeMissing | xltypeErr) 
		|| !args[num_searches][1].IsType(xltypeMulti))
			break;
	}
	while(++num_searches < 5);

	if(!num_searches)
		return p_xlErrValue;

// Check that all the input arrays are the same shape and size
	WORD rows, columns;
	WORD temp_rows, temp_columns;

	args[0][1].GetArraySize(rows, columns);

// Check that input is either single row or single column
	if(rows != 1 && columns != 1)
		return p_xlErrValue;

	for(int i = 1; i < num_searches; i++)
	{
		args[i][1].GetArraySize(temp_rows, temp_columns);

		if(rows != temp_rows || columns != temp_columns)
			return p_xlErrValue;
	}

	DWORD limit = rows * columns;
	DWORD offset;
	int count = 0;

// Simple search does not assume search ranges are sorted and
// looks for an exact match
	for(offset = 0; offset < limit; offset++)
	{
		int i;
		for(i = 0; i < num_searches; i++)
			if(args[i][0] != args[i][1].GetArrayElement(offset))
				break;

		if(i == num_searches)
			count++;
	}
	cpp_xloper RetVal(count);
	return RetVal.ExtractXloper();
}
