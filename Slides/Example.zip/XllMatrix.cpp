//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file (and header file) contain the definitions of simple
// classes for vectors and matrices of doubles.  They also contain an example
// function that calculates eigenvectors and eigenvalues for a real symmetric
// matrix.  A key passage of code is omitted for licensing reasons.  (See
// comment in code).
//============================================================================
//============================================================================
#include <windows.h>
#include <math.h>

#include "XllAddIn.h"
#include "XllMatrix.h"

#define MAX_JACOBI_ITERATIONS 200

//--------------------------------------------------------------------
void d_matrix::init(void)
{
	row_vec = NULL;
	data = NULL;
	n_columns = n_rows = 0;
	n_elements = 0;
	is_square = false;
}
//--------------------------------------------------------------------
bool d_matrix::allocate(void)
{
	if(!n_elements || !n_rows)
	{
		data = NULL;
		row_vec = NULL;
		return false;
	}
	data = new double[n_elements];
	row_vec = new double *[n_rows];

	double *p = data;
	for(int i = 0; i < n_rows; i++)
	{
		row_vec[i] = p;
		p += n_columns;
	}
	return true;
}
//--------------------------------------------------------------------
void d_matrix::Free(void)
{
	if(data)	delete[] data;
	if(row_vec)	delete[] row_vec;
	data = NULL;
	row_vec = NULL;
}
//--------------------------------------------------------------------
d_matrix::d_matrix(void)
{
	init();
}
//--------------------------------------------------------------------
d_matrix::d_matrix(WORD rows, WORD columns)
{
	Initialise(rows, columns);
}
//--------------------------------------------------------------------
void d_matrix::Initialise(WORD rows, WORD columns)
{
	init();

	if(!(rows && columns))
		return;

	n_columns = columns;
	n_rows = rows;
	n_elements = rows * columns;

	if(rows == columns)
		is_square = true;

	allocate();
}
//--------------------------------------------------------------------
void d_matrix::Initialise(WORD rows, WORD columns, double *init_data)
{
	n_columns = columns;
	n_rows = rows;
	n_elements = rows * columns;

	if(rows == columns)
		is_square = true;

	if(allocate())
		memcpy(data, init_data, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
void d_matrix::Set(WORD rows, WORD columns, double *input_data)
{
	if(n_columns != columns || n_rows != rows)
	{
		Free();
		Initialise(rows, columns, input_data);
		return;
	}

	memcpy(data, input_data, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
void d_matrix::SetDiagonal(double value)
{
	if(!is_square)
		return;

	double *p = data;

	for(WORD i = 0; i < n_rows; i++)
	{
		*p = value;
		p += (n_rows + 1);
	}
}
//--------------------------------------------------------------------
void d_matrix::SetLowerToUpper(void)
{
	if(!is_square)
		return;

	for(WORD r = 0; r < n_rows; r++)
	{
		for(WORD c = r + 1; c < n_rows; c++)
		{
			row_vec[c][r] = row_vec[r][c];
		}
	}
}
//--------------------------------------------------------------------
d_matrix::d_matrix(WORD rows, WORD columns, double *init_data)
{
	Initialise(rows, columns, init_data);
}
//--------------------------------------------------------------------
d_matrix::d_matrix(d_matrix &source)
  :	n_rows(source.n_rows),
	n_columns(source.n_columns),
	n_elements(source.n_elements),
	is_square(source.is_square)
{
	if(allocate())
		memcpy(data, source.data, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
d_matrix::~d_matrix(void)
{
	Free();
}
//--------------------------------------------------------------------
void d_matrix::operator=(d_matrix &source)
{
	Free();

	if(!(source.n_rows && source.n_columns && source.data))
	{
		init();
		return;
	}

	n_rows = source.n_rows;
	n_columns = source.n_columns;
	n_elements = source.n_elements;
	is_square = source.is_square;

	if(allocate())
		memcpy(data, source.data, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
void d_matrix::operator*=(double multiplier)
{
	for(long i = n_elements; --i >= 0;)
		data[i] *= multiplier;
}
//--------------------------------------------------------------------
void d_matrix::operator+=(double delta)
{
	for(long i = n_elements; --i >= 0;)
		data[i] += delta;
}
//--------------------------------------------------------------------
bool d_matrix::operator==(d_matrix &matrix2)
{
	if(n_rows != matrix2.n_rows || n_columns != matrix2.n_columns)
		return false;

	for(long i = n_elements; --i >= 0;)
		if(data[i] != matrix2.data[i])
			return false;

	return true;
}
//--------------------------------------------------------------------
d_matrix::operator double*(void)
{
	double *p = new double[n_elements];
	memcpy(p, data, sizeof(double) * n_elements);
	return p;
}
//--------------------------------------------------------------------
WORD d_matrix::GetRows(void)
{
	return n_rows;
}
//--------------------------------------------------------------------
WORD d_matrix::GetColumns(void)
{
	return n_columns;
}
//--------------------------------------------------------------------
double d_matrix::GetElement(WORD row, WORD column)
{
	if(row >= n_rows || column >= n_columns)
		return 0.0;

	return row_vec[row][column];
}
//--------------------------------------------------------------------
double d_matrix::GetElement(DWORD offset)
{
	if(offset >= n_elements)
		return 0.0;

	return data[offset];
}
//--------------------------------------------------------------------
bool d_matrix::SetElement(WORD row, WORD column, double value)
{
	if(row >= n_rows || column >= n_columns)
		return false;

	row_vec[row][column] = value;
	return true;
}
//--------------------------------------------------------------------
bool d_matrix::SetElement(DWORD offset, double value)
{
	if(offset >= n_elements)
		return false;

	data[offset] = value;
	return true;
}
//--------------------------------------------------------------------
void d_matrix::SetToZero(void)
{
	memset(data, 0, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
void d_matrix::SetToValue(double value)
{
	for(long i = n_elements; --i >= 0;)
		data[i] = value;
}
//--------------------------------------------------------------------
bool d_matrix::SetToIdentity(void)
{
	if(!is_square)
		return false;

	SetToZero();

	for(int i = 0; i < n_rows; i++)
		row_vec[i][i] = 1.0;

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::IsSquare(void)
{
	return n_rows && is_square;
}
//--------------------------------------------------------------------
bool d_matrix::IsSymetric(void)
{
	if(!is_square)
		return false;

	WORD r, c;

	for(r = 0; r < n_rows; r++)
		for(c = n_rows - 1; c > r; c--)
			if(row_vec[r][c] != row_vec[c][r])
				return false;

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::SwapColumns(WORD col_1, WORD col_2)
{
	if(col_1 >= n_columns || col_2 >= n_columns)
		return false;

	if(col_1 == col_2)
		return true;

	double temp;

	for(WORD r = 0; r < n_rows; r++)
	{
		temp = row_vec[r][col_1];
		row_vec[r][col_1] = row_vec[r][col_2];
		row_vec[r][col_2] = temp;
	}

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::SwapRows(WORD row_1, WORD row_2)
{
	if(row_1 >= n_rows || row_2 >= n_rows)
		return false;

	if(row_1 == row_2)
		return true;

	double *temp = new double[n_columns];
	memcpy(temp, row_vec[row_1], sizeof(double) * n_columns);
	memcpy(row_vec[row_1], row_vec[row_2], sizeof(double) * n_columns);
	memcpy(row_vec[row_2], temp, sizeof(double) * n_columns);
	delete[] temp;
	return true;
}
//--------------------------------------------------------------------
bool d_matrix::Transpose(void)
{
	if(!is_square)
		return false;

	double temp;

	for(int r = 0; r < n_rows; r++)
		for(int c = n_rows - 1; c > r; c--)
		{
			temp = row_vec[r][c];
			row_vec[r][c] = row_vec[c][r];
			row_vec[c][r] = temp;
		}

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::Transpose(d_matrix &source)
{
	Free();
	Initialise(source.n_columns, source.n_rows);
	
	if(!data)
		return false;

	for(int r = 0; r < n_rows; r++)
		for(int c = 0; c < n_columns; c++)
			row_vec[r][c] = source.row_vec[c][r];

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::Mult(d_matrix &mat1, d_matrix &mat2)
{
	return false;
}
//--------------------------------------------------------------------
bool d_matrix::CopyRow(short from_row, short to_row)
{
	if(from_row >= n_rows || to_row >= n_rows)
		return false;

	if(from_row == to_row)
		return true;

	memcpy(row_vec[to_row], row_vec[from_row], sizeof(double) * n_columns);
	return true;
}
//--------------------------------------------------------------------
bool d_matrix::InsertInRow(short row, short row_offset, double value)
{
	if(row >= n_rows || row_offset < 0 || row_offset >= n_columns)
		return false;

	if(row_offset < n_columns - 1)
		memcpy(row_vec[row] + row_offset + 1, row_vec[row] + row_offset, sizeof(double) * (n_columns - 1 - row_offset));

	row_vec[row][row_offset] = value;
	return true;
}
//--------------------------------------------------------------------
short d_matrix::JacobiCalc(d_vector &Evals, d_matrix &Evecs, int &n_rotations) 
{
	d_matrix a(*this);

// For licensing reasons the code here is omitted.  See Numerical
// Recipes in C and Numerical Recipes in C++ (Cambridge Press),
// Section 11.1 for the function jacobi(...) which can be called
// from here with suitable conversion of arguments from the
// d_matrix class given here to the matrix structures described in NRC.

	return 0;
}
//=====================================================================
bool d_matrix::GetEigenvectors(d_matrix &Evecs, d_vector &Evals)
{
	WORD i, j;
	int n_rotations;

//-------------------------------------------------------------------
//	Check that 'this' matrix is symetric
//-------------------------------------------------------------------
	if(!IsSymetric())
		return false;

	Evecs.Free();
	Evals.Free();
	Evecs.Initialise(n_rows, n_columns); // (re)create an N x N array for eigenvectors
	Evals.Initialise(n_rows); // (re)create an N-elt vector for eigegnvalues

	if(JacobiCalc(Evals, Evecs, n_rotations) == 0)
		return false;

//-------------------------------------------------------------------
//	Sort the columns and evals from highest eval to lowest
//-------------------------------------------------------------------
	for(i = 1; i < n_rows; i++)
		for(j = i; j > 0; j--)
			if(fabs(Evals.data[j]) > fabs(Evals.data[j-1]))
			{
				Evecs.SwapColumns(j, j-1);
				Evals.SwapElements(j, j-1);	
			}

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::InsertRow(d_vector &new_row, short position)
{
	if(new_row.n_elements != n_columns || position >= n_rows)
		return false;

	if(position < 0) // new row at bottom
	{
		n_rows++;
		n_elements += n_columns;
		double *temp_data = data;
		delete[] row_vec;

// Reallocate and reinitialise data and row_vec with new size
		allocate();

		memcpy(data, temp_data, sizeof(double) * (n_elements - n_columns));
		memcpy(row_vec[n_rows - 1], new_row.data, sizeof(double) * n_columns);
		delete[] temp_data;
		return true;
	}
	return false;
}
//--------------------------------------------------------------------
bool d_matrix::InsertColumn(d_vector &new_column, short position)
{
	if(new_column.n_elements != n_rows || position >= n_columns)
		return false;

	if(position < 0) // new column at right
		return false; // not coded yet

	return false;
}
//--------------------------------------------------------------------
bool d_matrix::MultRow(short row, double multiplier)
{
	if(row < 0 || row >= n_rows)
		return false;

	double *p = row_vec[row];

	for(int c = 0; c < n_columns; c++)
		p[c] *= multiplier;

	return true;
}
//--------------------------------------------------------------------
bool d_matrix::MultColumn(short col, double multiplier)
{
	if(col < 0 || col >= n_columns)
		return false;

	for(int r = 0; r < n_rows; r++)
		row_vec[r][col] *= multiplier;

	return true;
}
//====================================================================
//====================================================================
//====================================================================
//====================================================================
//====================================================================
void d_vector::init(void)
{
	data = NULL;
	n_elements = 0;
}
//--------------------------------------------------------------------
bool d_vector::allocate(void)
{
	data = new double[n_elements];
	return true;
}
//--------------------------------------------------------------------
void d_vector::Free(void)
{
	if(data) delete[] data;
	data = NULL;
}
//--------------------------------------------------------------------
d_vector::d_vector(void)
{
	init();
}
//--------------------------------------------------------------------
void d_vector::Initialise(WORD elements)
{
	if(n_elements = elements)
		allocate();
	else
		data = NULL;
}
//--------------------------------------------------------------------
void d_vector::Initialise(WORD elements, double *init_data)
{
	if((n_elements = elements) && allocate())
		memcpy(data, init_data, sizeof(double) * n_elements);
	else
		data = NULL;
}
//--------------------------------------------------------------------
void d_vector::Set(WORD elements, double *input_data)
{
	if(n_elements != elements)
	{
		Free();
		Initialise(elements, input_data);
		return;
	}
	memcpy(data, input_data, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
d_vector::d_vector(WORD elts)
{
	Initialise(elts);
}
//--------------------------------------------------------------------
d_vector::d_vector(WORD elements, double *init_data)
{
	Initialise(elements, init_data);
}
//--------------------------------------------------------------------
d_vector::d_vector(d_vector &source)
{
	Initialise(source.n_elements, source.data);
}
//--------------------------------------------------------------------
d_vector::~d_vector(void)
{
	Free();
	init();
}
//--------------------------------------------------------------------
void d_vector::operator=(d_vector &source)
{
	Free();
	Initialise(source.n_elements, source.data);
}
//--------------------------------------------------------------------
void d_vector::operator*=(double multiplier)
{
	for(long i = n_elements; --i >= 0;)
		data[i] *= multiplier;
}
//--------------------------------------------------------------------
void d_vector::operator+=(double delta)
{
	for(long i = n_elements; --i >= 0;)
		data[i] += delta;
}
//--------------------------------------------------------------------
bool d_vector::operator==(d_vector &vector2)
{
	if(n_elements != vector2.n_elements)
		return false;

	for(long i = n_elements; --i >= 0;)
		if(data[i] != vector2.data[i])
			return false;

	return true;
}
//--------------------------------------------------------------------
d_vector::operator double*(void)
{
	double *p = new double[n_elements];
	memcpy(p, data, sizeof(double) * n_elements);
	return p;
}
//--------------------------------------------------------------------
WORD d_vector::GetElts(void)
{
	return n_elements;
}
//--------------------------------------------------------------------
double d_vector::GetElement(WORD elt)
{
	if(elt >= n_elements)
		return 0.0;

	return data[elt];
}
//--------------------------------------------------------------------
bool d_vector::SetElement(WORD elt, double value)
{
	if(elt >= n_elements)
		return false;

	data[elt] = value;
	return true;
}
//--------------------------------------------------------------------
void d_vector::SetToZero(void)
{
	memset(data, 0, sizeof(double) * n_elements);
}
//--------------------------------------------------------------------
void d_vector::SetToValue(double value)
{
	for(long i = n_elements; --i >= 0;)
		data[i] = value;
}
//--------------------------------------------------------------------
bool d_vector::SwapElements(WORD elt_1, WORD elt_2)
{
	if(elt_1 >= n_elements || elt_2 >= n_elements)
		return false;

	if(elt_1 != elt_2)
	{
		double temp = data[elt_1];
		data[elt_1] = data[elt_2];
		data[elt_2] = temp;
	}
	return true;
}
//=====================================================================
//=====================================================================
// Excel interface function for calculating eigenvectors and
// eigenvalues of real square symetric matrices
//=====================================================================
//=====================================================================
xloper * __stdcall eigen_system(xl_array *p_input)
{
	if(called_from_paste_fn_dlg())
		return NULL;

	WORD rows = p_input->rows;
	WORD columns = p_input->columns;

	if(rows < 2 || rows > 100 || rows != columns)
		return p_xlErrValue;

	d_matrix Mat(rows, columns, p_input->array);
	d_matrix Eigenvectors;
	d_vector Eigenvalues;

	if(!Mat.GetEigenvectors(Eigenvectors, Eigenvalues)
	|| !Eigenvectors.InsertRow(Eigenvalues, -1))
		return p_xlErrNum;

	cpp_xloper Output(rows + 1, columns, Eigenvectors.data);
	return Output.ExtractXloper();
}
//=====================================================================
//=====================================================================
// VBA interface function for calculating eigenvectors and
// eigenvalues of real square symetric matrices
//=====================================================================
//=====================================================================
VARIANT __stdcall VBA_eigen_system(VARIANT *pv)
{
	static VARIANT vt;
// Convert the passed-in Variant to an xloper within a cpp_xloper
	cpp_xloper Array(pv);

// Convert the xloper to an xl_array of doubles
	xl_array *p_array = Array.AsDblArray();

	if(!p_array)
	{
		xloper_to_vt(p_xlErrValue, vt, false);
		return vt;
	}

// Attempt to convert the array to an xloper xltypeMulti containing
// the required output. Function returns a pointer to a static xloper
	xloper *p_op = eigen_system(p_array);

	free(p_array); // Don't need this anymore

// Re-use the Array cpp_xloper. Assignment operator makes a shallow
// copy and preserves the correct destructor information, i.e.,
// takes note if either xlbitXLFree or xlbitDLLFree bits set.
// No need to check if p_op is NULL - assignment operator checks.
	Array = p_op;

// Convert the xloper back to a Variant
	Array.AsVariant(vt);
	return vt;
}