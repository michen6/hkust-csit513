//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples relating to the use of VB as an
// interface to the DLL.  It contains examples of functions that demonstrate
// the acceptance from and return to VBA of different data types.
//============================================================================
//============================================================================
#include <windows.h>
#include <stdio.h>

#include "cpp_xloper.h"

//--------------------------------------------
// Excel worksheet cell error codes are passed
// via VB OLE Variant arguments in 'ulVal'.
// These are equivalent to the offset below
// plus the value defined in "xlcall.h"
//
// This is easier than using VT_SCODE scode
//--------------------------------------------
#define VT_XL_ERR_OFFSET		2148141008ul

#define MAX_DIMS	2  // convert SafeArrays up to 2-dims only

//===========================================
double __stdcall C_VB_array_example(double *p, short rows, short cols)
{
	int r, c;
	double sum = 0.0;

	if(!p)	return 0.0;

	for(r = 0; r < rows; r++)
		for(c = 0; c < cols; c++)
			sum += *p++;

	return sum;
}
//===========================================
short __stdcall C_vt_type(VARIANT *pv)
{
	if(!pv)
		return 0;

	return (short)pv->vt;
}
//===========================================
BSTR __stdcall C_vt_array_info(VARIANT *pv)
{
	if((pv->vt | VT_ARRAY) == 0)
		return SysAllocStringByteLen("Not an array", 12);

// Check that the SafeArray contained within the Variant
// has been created and dimensioned, and get its type.
	VARTYPE vt_type;

	if(!pv->parray || SafeArrayGetVartype(pv->parray, &vt_type))
		return SysAllocStringByteLen("Couldn't get data type", 22);

// Check the dimensions.
	long dims = SafeArrayGetDim(pv->parray);

	if(dims  < 1 || dims > MAX_DIMS)
		return SysAllocStringByteLen("Couldn't get dims", 17);

// Get the upper and lower bounds and calculate the dimension
// sizes for rows and columns.  (If only one dimension in the
// input array, it's a column vector so the second dimension = 1).
	long dim_size[MAX_DIMS] = {1, 1};
	long Ubound, Lbound;

	for(long i = 1; i <= dims; i++)
	{
		if(SafeArrayGetLBound(pv->parray, i, &Lbound) < 0
		|| SafeArrayGetUBound(pv->parray, i, &Ubound) < 0)
			return SysAllocStringByteLen("Couldn't get bounds", 19);

		dim_size[i - 1] = Ubound - Lbound + 1;
	}

	char buffer[256];
	int len = sprintf(buffer, "Type:%d, Dims:%d, Rows:%d, Cols:%d",
		vt_type, dims, dim_size[0], dim_size[1]);

	return SysAllocStringByteLen(buffer, len);
}
//===========================================
VARIANT __stdcall C_vt_array_example(VARIANT *pv)
{
	VARIANT vt;
// Convert the passed-in Variant to an xloper within a cpp_xloper
	cpp_xloper Array(pv);

// Access the elements of the xloper array using the cpp_xloper
// accessor functions...

// Convert the xloper back to a Variant and return it
	Array.AsVariant(vt);
	return vt;
}
//===========================================
double __stdcall C_variant_value(VARIANT *p)
{
	if(!p)
		return 0.0;

	switch(p->vt)
	{
	case VT_R8:			return p->dblVal;
	case VT_BOOL:		return p->boolVal;
	case VT_DATE:		return p->date;
	case VT_BSTR:		return atof((char *)(p->bstrVal));
	case VT_CY:			return (double)p->cyVal.int64;
	case VT_ERROR:		return p->ulVal;
	case VT_EMPTY:		return 0;
	case VT_VARIANT:	return 0;
	}
	return 0.0;
}
//===========================================
// Function definition corresponding to VB definition of
// Declare Function C_BSTR_Example1 ...(s As String) As Boolean,
// i.e. argument passed ByRef.
//===========================================
short __stdcall C_BSTR_example1(BSTR *ptr_bstr)
{
	if(!ptr_bstr) // Should never be NULL, but...
		return 0; // Return VB False

	if(!*ptr_bstr) // Is string initialised?
		return 0; // Return VB False if not

	for(int i = 0; ; i++)
	{
		if(!((char *)(*ptr_bstr))[i])
			break;
	}
	return -1; // Return VB True
}
//=================================================
// Example code to create and return a BSTR to VBA
// Creates a string of the 1st 'n' A-Z chars.
//=================================================
BSTR __stdcall C_BSTR_example2(short n)
{
	if(n <= 0 || n > 26)
		return NULL;

// 1st argument is initialisation string, but we want
// to initialise this ourselves so pass NULL.  2nd
// argument is number of bytes in the byte-string NOT
// including the null termination space for which is
// allocated and which is added by SysAllocStringByteLen()
//
// Returns NULL is unsuccessful at allocating memory, which
// must freed by a call to SysFreeString().  In this
// example, freeing memory is left to the caller, i.e. VBA

	BSTR bstr = SysAllocStringByteLen(NULL, n);

	if(*bstr)
	{
		char c = 'A';

		for(int i = 0; i < n;)
			((char *)(bstr))[i++] = c++;
	}
	return bstr;
}
//===========================================
#pragma pack(4) // required to be consistent with VBA

typedef struct
{
    short iVal;
    double dVal;
    BSTR bstr;
}
	C_user_type;

#pragma pack() // restore the default

//=================================================
short __stdcall C_user_type_example(C_user_type *arg)
{
	short retval;

	if(arg == NULL)
		return 0;

	retval = arg->iVal;
	retval += (int)(arg->dVal);

	if(arg->bstr)
		retval += SysStringByteLen(arg->bstr);

	return retval;
}
//=================================================
double __stdcall C_DATE_example(DATE date)
{
	double d = date;
	return d;
}
