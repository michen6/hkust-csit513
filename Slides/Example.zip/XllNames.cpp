//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file (and header file) contain the definition of a class for
// managing and accessing Excel names, both worksheet names and DLL-internal
// names.  It contains examples of the use of this class and an STL container
// for managing DLL-internal Excel names.
//============================================================================
//============================================================================
#include <windows.h>
#include <stdio.h>
#include <time.h>

// Needed because of Microsoft bug: See Article ID: Q167355 
#pragma warning(disable:4786)

#include "XllAddIn.h"
#include "XllNames.h"

#include <map>
#include <string>

//==================================================
//==================================================
//==================================================
//
// Structures and functions for management of list
// of internal xll Excel names.
//
//==================================================
//==================================================
//==================================================

// Local class. Only requires one specialized contructor
// Default constructor is hidden.
// No copy/assignment constructors required

struct name_list_elt
{
	name_list_elt(xlName &R, void *fn_ptr)
		: m_R(R), m_fn_ptr(fn_ptr) {}

	xlName m_R;
	void * m_fn_ptr;

private :
	name_list_elt(); // no implementation
};

// Internal range name map will hold a copy of the name in
// a std::string which we'll map to name_list_elt

typedef std::map<std::string, name_list_elt*> MAP_NAMES;

MAP_NAMES mapNames;

char *make_unique_name(void);
int __stdcall clean_xll_name_list(void);

//==================================================
bool add_name_record(void *fn_ptr, xlName &Range)
{
	char *range_name = Range.GetName();

	if(!range_name)
		return false;	// can't add when there's no name
	
	std::string sRangeName = range_name;
	
	free(range_name);	// release deep copy from GetName

	name_list_elt* pElement = new name_list_elt(Range, fn_ptr);
	
	if(!pElement)
		return false;

// Not strictly necesary but clear out any rubbish before
// looking for existing name.  Could be inefficient if
// list of internal names is long, and could be safely
// removed.
	clean_xll_name_list();

	MAP_NAMES::iterator iterNames = mapNames.find(sRangeName);

	if(iterNames != mapNames.end())
		return false; // Range Name already in map	

	mapNames[sRangeName] = pElement;
	return true;
}
//==================================================
// Return the funtion pointer that was associated
// with this DLL-internal name
//==================================================
void *find_name_record_fn_ptr(xlName &Range)
{
	char *range_name = Range.GetName();

	if(!range_name)
		return false;	// can't add when there's no name
	
	std::string sRangeName = range_name;
	
	free(range_name);	// release deep copy from GetName

// Not strictly necesary but clear out any rubbish before
// looking for existing name.  Could be inefficient if
// list of internal names is long, and could be safely
// removed.
	clean_xll_name_list();

	MAP_NAMES::iterator iterNames = mapNames.find(sRangeName);

	if(iterNames == mapNames.end())
		return false; // Range Name not found
	
	name_list_elt* pElement = (*iterNames).second;

	return pElement->m_fn_ptr;
}
//==================================================
int __stdcall clean_xll_name_list(void)
{
	if(mapNames.size() == 0)
		return 0;

	MAP_NAMES::iterator iterNames = mapNames.begin();

	while(iterNames != mapNames.end())
	{
		name_list_elt* pElement = (*iterNames).second;		
	
		if(!pElement->m_R.Refresh())
		{
// If the range is no longer valid remove it
			pElement->m_R.Delete();
			delete pElement;

// erase returns iterator to next valid entry or to end()
			iterNames = mapNames.erase(iterNames);
		}
		else
		{
			iterNames++;
		}
	}
	return 1;
}
//==================================================
int __stdcall delete_all_xll_names(void)
{
	if(mapNames.size() == 0)
		return 0;

	MAP_NAMES::iterator iterNames = mapNames.begin();

	while(iterNames != mapNames.end())
	{
		name_list_elt* pElement = (*iterNames).second;		
		pElement->m_R.Delete();
		delete pElement;

// erase returns iterator to next valid entry or to end()
		iterNames = mapNames.erase(iterNames);
	}
	return 1;
}
//==================================================
//==================================================
//==================================================
//
// class xlName
//
//==================================================
//==================================================
//==================================================

//==================================================
// Create a reference to an existing Excel name
//==================================================
bool xlName::Set(char *name)
{
	m_Defined = m_RefValid = m_Worksheet = false;

	if(!name || !*name)
		return false;

	m_Worksheet = (strchr(name, '!') != NULL);
	m_RangeName = name;

// If name exists and is internal, add to the list.
// add_name_record() has no effect if already there.
	if(Refresh())
	{
		if(!m_Worksheet)
			add_name_record(NULL, *this);

		return true;
	}
	return false;
}
//==================================================
// Set to the corresponding name if it exists
//==================================================
bool xlName::SetToRef(xloper *p_ref_oper, bool internal)
{
	Clear();

	if((p_ref_oper->xltype & (xltypeSRef | xltypeRef)) == 0)
		return false;

//-----------------------------------------------------------
// Convert to text of form [Book1.xls]Sheet1! R1C1
//-----------------------------------------------------------
	cpp_xloper RefTextR1C1;
	int xl4 = Excel4(xlfReftext, &RefTextR1C1, 1, p_ref_oper);
	RefTextR1C1.SetExceltoFree();

	if(xl4 || RefTextR1C1.IsType(xltypeErr))
		return false;

//-----------------------------------------------------------
// Get the name, if it exists, otherwise fail.
//
// First look for an internal name (the default if the 2nd
// argument to xlfGetDef is omitted).
//-----------------------------------------------------------
	if(internal)
	{
		xl4 = Excel4(xlfGetDef, &m_RangeName, 1, &RefTextR1C1);
		m_RangeName.SetExceltoFree();

		if(xl4 || !m_RangeName.IsType(xltypeStr))
			return m_Defined = m_RefValid = false;

		m_Worksheet = false;
// If name exists and is internal, add to the list.
// add_name_record() has no effect if already there.
		add_name_record(NULL, *this);
	}
	else
	{
// Extract the sheet name and specify this explicitly
		cpp_xloper SheetName;
		xl4 = Excel4(xlSheetNm, &SheetName, 1, p_ref_oper);
		SheetName.SetExceltoFree();

		if(xl4 || !SheetName.IsType(xltypeStr))
			return m_Defined = m_RefValid = false;

// Truncate RefTextR1C1 at the R1C1 part
		char *p = (char *)RefTextR1C1; // need to free this
		RefTextR1C1 = strchr(p, '!') + 1;
		free(p); // free the deep copy

// Truncate SheetName at the sheet name
		p = (char *)SheetName;
		SheetName = strchr(p, ']') + 1;
		free(p); // free the deep copy

		xl4 = Excel4(xlfGetDef, &m_RangeName, 2, &RefTextR1C1, &SheetName);
		m_RangeName.SetExceltoFree();

		if(xl4 || !m_RangeName.IsType(xltypeStr))
			return m_Defined = m_RefValid = false;

		m_Worksheet = true;
	}
	return m_Defined = m_RefValid = true;
}
//==================================================
// Set to be the range associated with caller or return
// false if none exists. If dll_only == true, only look for
// an internal worksheet name
//==================================================
bool xlName::SetToCallersName(void)
{
	Clear();

// Get a reference to the calling cell
	cpp_xloper Caller;
	int xl4 = Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();

	if(xl4) // if xlfCaller failed
		return false;

	return SetToRef(&Caller, true); // true: look for internal name
}
//==================================================
// Clears memory associated with this instance but does not delete range
//==================================================
void xlName::Clear(void)
{
	if(m_Defined)
	{
		m_Defined = m_RefValid = m_Worksheet = false;
		m_RangeName.Free();
		m_RangeRef.Free();
	}
}
//==================================================
char *xlName::GetName(void)
{
	if(!m_Defined)
		return NULL;

	return (char *)m_RangeName;
}
//==================================================
bool xlName::NameIs(char *name)
{
	char *p = (char *)m_RangeName;

	if(!p)
		return false;

	bool same_name = (strcmp(name, p) == 0);
	free(p);
	return same_name;
}
//==================================================
bool xlName::Refresh(void)
{
	m_RangeRef.Free();

//-----------------------------------------------------------
// First check that the name is defined
//-----------------------------------------------------------
	cpp_xloper Defn;
	int xl4 = Excel4(xlfGetName, &Defn, 1, &m_RangeName);
	Defn.SetExceltoFree();

	if(xl4 || !Defn.IsType(xltypeStr))
		return m_Defined = m_RefValid = false;

	m_Defined = true;

//-----------------------------------------------------------
// Now check if the definition is a valid reference
//-----------------------------------------------------------
	char *temp = (char *)Defn; // allocates some memory
	Defn = temp + 1; // remove the leading '='
	free(temp); // free the temporary memory

	xl4 = Excel4(xlfTextref, &m_RangeRef, 2, &Defn, p_xlFalse);
	m_RangeRef.SetExceltoFree();

	m_RefValid = !xl4 && m_RangeRef.IsType(xltypeSRef | xltypeRef);
	return m_RefValid;
}
//==================================================
char * xlName::GetDef(void) // get defintion as string (caller must free)
{
	cpp_xloper Defn;
	int xl4 = Excel4(xlfGetName, &Defn, 1, &m_RangeName);
	Defn.SetExceltoFree();

	if(xl4 || !Defn.IsType(xltypeStr))
		return NULL;

	return (char *)Defn;
}
//==================================================
bool xlName::NameCaller(char *name)
{
//-----------------------------------------------------------
// Check if given internal name already exists for this caller
//-----------------------------------------------------------
	if(SetToCallersName() && !m_Worksheet)
	{
// If no name specified, then the existing name is what's required
		if(!name || !*name)
			return true;

// Check if name is the same as the specified one
		if(m_RangeName == name)
			return true;

// If not, delete the old name, create a new one.
		Delete();
	}

//-----------------------------------------------------------
// If no name provided, create a unique name
//-----------------------------------------------------------
	if(!name || !*name)
	{
		name = make_unique_name();
		m_RangeName = name;
		free(name);
	}
	else
	{
		m_RangeName = name;
	}
	m_Worksheet = false;  // This will be an internal name

//-----------------------------------------------------------
// Get a reference to the calling cell
//-----------------------------------------------------------
	cpp_xloper Caller;
	int xl4 = Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();

	if(xl4) // if xlfCaller failed
		return m_Defined = m_RefValid = false;

//-----------------------------------------------------------
// Associate the new internal name with the calling cell(s)
//-----------------------------------------------------------
	cpp_xloper RetVal;
	xl4 = Excel4(xlfSetName, &RetVal, 2, &m_RangeName, &Caller);
	RetVal.SetExceltoFree();

	if(xl4 || RetVal.IsType(xltypeErr))
		return m_Defined = m_RefValid = false;

//-----------------------------------------------------------
// Add the new internal name to the list
//-----------------------------------------------------------
	m_Defined = m_RefValid = true;
	add_name_record(NULL, *this);
	return true;
}
//==================================================
// If defined, deletes the given name and frees resources
//==================================================
void xlName::Delete(void)
{
	if(Refresh())
	{
		if(m_Worksheet) // Can only do this in a command
			Excel4(xlcDeleteName, 0, 1, &m_RangeName);
		else // Internal names can be deleted any time
			Excel4(xlfSetName, 0, 1, &m_RangeName);
	}
	Clear();
}
//==================================================
// Change (or define for the first time) the defition
// of the range name already associated with this
// instance of xlName
//==================================================
bool xlName::Define(xloper *p_defintion, bool in_dll)
{
// Delete any existing definition for this range name
	Delete();

	m_Worksheet = !in_dll;

// Create a new definition
	cpp_xloper RetVal;
	int xl4;

	if(in_dll) // a hidden internal dll name
	{
		xl4 = Excel4(xlfSetName, &RetVal, 2, &m_RangeName, p_defintion);
// Add to the list of DLL-internal names, enabling clear up
		add_name_record(NULL, *this);
	}
	else // a worksheet name.  Can only do this in a command
	{
		xl4 = Excel4(xlcDefineName, &RetVal, 2, &m_RangeName, p_defintion);
	}
	RetVal.SetExceltoFree();

	if(xl4 || RetVal.IsType(xltypeErr))
		return m_Defined = m_RefValid = false;

	return m_Defined = m_RefValid = true;
}
//==================================================
// Create (or define for the first time) a named range
// and associate it with this instance of xlName
bool xlName::Define(char *name, xloper *p_defintion, bool in_dll)
{
	if(!name || !*name)
		return false;

	m_RangeName = name;

	return Define(p_defintion, in_dll);
}
//==================================================
xlName & xlName::operator=(const xlName &source)
{
	if(&source == this)
		return *this;

	m_Defined = source.m_Defined;
	m_RefValid = source.m_RefValid;
	m_Worksheet = source.m_Worksheet;

// cpp_xloper assignment operator makes deep copies
	m_RangeRef = source.m_RangeRef;
	m_RangeName = source.m_RangeName;
	return *this;
}
//==================================================
// Overloaded operators
//==================================================
// Assignment operators place values in cell(s) that
// range refers to.  Cast operators retrieve values
// or assign nil if range is not valid or conversion
// was not possible.  Casting to char * will (and
// xloper * can) return dynamically allocated memory
// that the caller must free.
//
// Retrieving values is easier than setting them, as
// it is not necessary to refresh the reference first
//==================================================
void xlName::operator=(int i)
{
	if(!Refresh())
		return;

	xloper temp = {(double)i, xltypeNum};
	Excel4(xlSet, 0, 2, &m_RangeRef, &temp);
}
//==================================================
void xlName::operator=(bool b)
{
	if(!Refresh())
		return;

	cpp_xloper Value(b);
	Excel4(xlSet, 0, 2, &m_RangeRef, &Value);
}
//==================================================
void xlName::operator=(double d)
{
	if(!Refresh())
		return;

	xloper temp = {d, xltypeNum};
	Excel4(xlSet, 0, 2, &m_RangeRef, &temp);
}
//==================================================
void xlName::operator=(WORD xl_error)
{
	if(!Refresh())
		return;

	cpp_xloper Value(xl_error);
	Excel4(xlSet, 0, 2, &m_RangeRef, &Value);
}
//==================================================
void xlName::operator=(char *s)
{
	if(!Refresh())
		return;

	cpp_xloper Value(s);
	Excel4(xlSet, 0, 2, &m_RangeRef, &Value);
}
//==================================================
void xlName::operator=(xloper *p_op)
{
	if(!Refresh())
		return;

	Excel4(xlSet, 0, 2, &m_RangeRef, p_op);
}
//==================================================
void xlName::operator=(VARIANT *p_var)
{
	if(!Refresh())
		return;

	cpp_xloper Value(p_var);
	Excel4(xlSet, 0, 2, &m_RangeRef, &Value);
}
//==================================================
void xlName::operator=(xl_array *array)
{
	if(!Refresh())
		return;

	cpp_xloper Value(array->rows, array->columns, array->array);
	Excel4(xlSet, 0, 2, &m_RangeRef, &Value);
}
//==================================================
void xlName::operator+=(double d)
{
	if(!Refresh())
		return;

	xloper value;
	cpp_xloper Type(xltypeNum);

	int xl4 = Excel4(xlCoerce, &value, 2, &m_RangeRef, &Type);

	if(xl4 || value.xltype != xltypeNum)
		return;

	value.val.num += d;
	Excel4(xlSet, 0, 2, &m_RangeRef, &value);
}
//==================================================
// Retrieving values is easier than setting them, as
// it is not necessary to refresh the reference first
//==================================================
xlName::operator int(void)
{
	cpp_xloper Value;
	int xl4 = Excel4(xlfEvaluate, &Value, 1, &m_RangeName);
	Value.SetExceltoFree();

	if(!xl4)
	{
		cpp_xloper Type(xltypeNum);
		cpp_xloper IntValue;

		if(!Excel4(xlCoerce, &IntValue, 2, &Value, &Type))
			return (int)IntValue;
	}
	return 0;
}
//==================================================
xlName::operator bool(void)
{
	cpp_xloper Value;
	int xl4 = Excel4(xlfEvaluate, &Value, 1, &m_RangeName);
	Value.SetExceltoFree();

	if(!xl4)
	{
		cpp_xloper Type(xltypeBool);
		cpp_xloper BoolValue;

		if(!Excel4(xlCoerce, &BoolValue, 2, &Value, &Type))
			return (bool)BoolValue;
	}
	return false;
}
//==================================================
xlName::operator double(void)
{
	cpp_xloper Value;
	int xl4 = Excel4(xlfEvaluate, &Value, 1, &m_RangeName);
	Value.SetExceltoFree();

	if(!xl4)
	{
		cpp_xloper Type(xltypeNum);
		cpp_xloper DblValue;

		if(!Excel4(xlCoerce, &DblValue, 2, &Value, &Type))
			return (double)DblValue;
	}
	return 0.0;
}
//==================================================
xlName::operator char *(void) // returns range contents as string
{
	cpp_xloper Value;
	int xl4 = Excel4(xlfEvaluate, &Value, 1, &m_RangeName);
	Value.SetExceltoFree();

	if(!xl4)
	{
		cpp_xloper Type(xltypeStr);
		cpp_xloper StrValue;
		xl4 = Excel4(xlCoerce, &StrValue, 2, &Value, &Type);
		StrValue.SetExceltoFree();

		if(!xl4)
			return (char *)StrValue;
	}
	return NULL;
}
//==================================================
// Retrieve the named range contents as xltypeMulti
// This is a two-stage process:
// 1. Convert the text name to a ref using xlfEvaluate
// 2. Convert the ref to xltypeMulti using xlCoerce
bool xlName::GetValues(cpp_xloper &Values)
{
	Values.Clear();

	cpp_xloper Range;
	int xl4 = Excel4(xlfEvaluate, &Range, 1, &m_RangeName);
	Range.SetExceltoFree();

	if(!xl4)
	{
		cpp_xloper Type(xltypeMulti);
		xl4 = Excel4(xlCoerce, &Values, 2, &Range, &Type);
		Values.SetExceltoFree();

		return (xl4==xlretSuccess && Values.IsMulti());
	}
	return false;
}
//==================================================
bool xlName::SetValues(cpp_xloper &Values)
{
// Assign Values to named range
	return Refresh()
		&& Excel4(xlSet, 0, 2, &m_RangeRef, &Values) == xlretSuccess;
}
//==================================================
void xlName::SetNote(char *text)
{
	if(!Refresh())
		return;

	int xl4;

	if(text)
	{
		cpp_xloper Note(text);
		xl4 = Excel4(xlcNote, 0, 2, &Note, &m_RangeRef);
	}
	else
	{
		xl4 = Excel4(xlcNote, 0, 2, p_xlMissing, &m_RangeRef);
	}
}
//==================================================
char * xlName::GetNote(void)
{
	if(!Refresh())
		return NULL;

	cpp_xloper Note;
	int xl4 = Excel4(xlcNote, 0, 2, &Note, &m_RangeRef);
	Note.SetExceltoFree();

	if(xl4 || !Note.IsStr())
		return NULL;

	return (char *)Note;
}
//==================================================
// End of xlName code
//==================================================


//========================================================
//========================================================
//========================================================
//========================================================
char *make_unique_name(void)
{
	time_t time_t_T;
	static long name_count = 0;
	static unsigned long T_last = 0;

	time(&time_t_T);
	tm tm_T = *localtime(&time_t_T);

// Need an unsigned long to contain max possible value
	unsigned long T = tm_T.tm_sec
		+ 60 * (tm_T.tm_min
		+ 60 * (tm_T.tm_hour
		+ 24 * (tm_T.tm_yday
		+ 366 * tm_T.tm_year % 100)));

	if(T != T_last)
	{
		T_last = T;
		name_count = 0;
	}

	char buffer[32]; // More than enough space

// Increment name_count so that names created in the current
// second are still unique.  The name_count forms the first
// part of the name.
	int ch_count = sprintf(buffer, "x%ld.", ++name_count);

	int r;
// Represent the time number in base 62 using 0-9, A-Z, a-z.
// Puts the characters most likely to differ at the front
// of the name to optimise name searches and comparisons
	for(;T; T /= 62)
	{
		if((r = T % 62) < 10)
			r += '0';
		else if(r < 36)
			r += 'A' - 10;
		else
			r += 'a' - 36;

		buffer[ch_count++] = r;
	}
	buffer[ch_count] = 0;

// Make a copy of the string and return it
	char *new_name = (char *)malloc(ch_count + 1);
	strcpy(new_name, buffer);
	return new_name; // caller must free the memory
}


//==================================================
//==================================================
//==================================================
// Exported example worksheet functions
// and Excel commands
//==================================================
//==================================================
//==================================================


//==================================================
// This function gets the definition associated with
// the given name, which can be a worksheet name or
// an internal name depending on the 2nd arg
//==================================================
xloper * __stdcall range_name(xloper *p_ref, xloper *p_dll)
{
	xlName R;

// Are we looking for a worksheet name or a DLL name?
	bool dll = (p_dll->xltype==xltypeBool && p_dll->val._bool != 0);

	if(!R.SetToRef(p_ref, dll))
		return p_xlErrRef;

	char *p = R.GetName();
	cpp_xloper RetVal(p);
	free(p);

	return RetVal.ExtractXloper();
}
//==================================================
// Creates an internal name or returns its value
// depending on whether the 2nd arg is omitted.
// New names are defined as whatever is passed in
// using the 2nd arg unless p_as_value is boolean true
// in which case references are converted to values.
//==================================================
xloper * __stdcall xll_name(char *name_text, xloper *p_defn, xloper *p_as_value, xloper *p_delete)
{
	cpp_xloper Name(name_text); // make a deep copy
	cpp_xloper Defn(p_defn); // make a shallow copy
	cpp_xloper AsValue(p_as_value); // shallow copy
	cpp_xloper Delete(p_delete);
	cpp_xloper RetVal;
	int xl4;

	if(Delete == true)
	{
		Excel4(xlfSetName, 0, 1, &Name);
// Remove from the DLL's list of internal names.
		clean_xll_name_list();
		return p_xlTrue;
	}

	if(Defn.IsType(xltypeNil | xltypeMissing))
	{
// function is just asking for the name to be evaluated
		Excel4(xlfEvaluate, &RetVal, 1, &Name);
		return RetVal.ExtractXloper(true);
	}

	if(AsValue==true && Defn.IsType(xltypeSRef | xltypeRef))
	{
// Create a name defined as the value of the given reference
		cpp_xloper Val;
		xl4 = Excel4(xlCoerce, &Val, 1, &Defn);
		Val.SetExceltoFree();

		if(xl4 || Val.IsType(xltypeErr))
			return p_xlFalse;

		Excel4(xlfSetName, &RetVal, 2, &Name, &Val);
	}
	else
	{
// Create a name defined as the given reference
		Excel4(xlfSetName, &RetVal, 2, &Name, &Defn);
	}

// Add to DLL's list of internal names.  Done automatically by the
// the xlName constructor
	xlName R(name_text);
	return RetVal.ExtractXloper(true);
}
//==================================================
// Returns a 2-column array of internal names and
// definitions
//==================================================
xloper * __stdcall get_xll_names(int trigger)
{
	clean_xll_name_list();

	long num_names = mapNames.size();

	if(!num_names)
		return p_xlErrNa;

	cpp_xloper RetVal((WORD)num_names, (WORD)2);
	DWORD offset = 0;
	name_list_elt *pElement;

	for (MAP_NAMES::iterator iterNames = mapNames.begin(); iterNames != mapNames.end(); iterNames++)
	{
		pElement = (*iterNames).second;
		RetVal.SetArrayElement(offset++, pElement->m_R.GetName());
		RetVal.SetArrayElement(offset++, pElement->m_R.GetDef());
	}
	return RetVal.ExtractXloper();
}
//==================================================
xloper * __stdcall name_me(int create)
{
	if(called_from_paste_fn_dlg())
		return p_xlErrValue;

// Set the xlName to refer to the calling cell.
	xlName Caller;
	bool name_exists = Caller.SetToCallersName();

	if(create)
	{
		if(!name_exists)
			Caller.NameCaller(NULL);

// Get the defined name.  Need to free this string.
		char *name = Caller.GetName();
		cpp_xloper Name(name);
		free(name);
		return Name.ExtractXloper();
	}

// Not creating, so deleting
	if(!name_exists)
		return p_xlFalse;

// Delete from Excel's own list of defined names
	Caller.Delete();

// Delete from DLL's list of internal names.  This is a
// slightly inefficient method, especially if a large
// number of internal names are in the list.  A more
// specific method of deleting from list could easily
// be coded.
	clean_xll_name_list();
	return p_xlTrue;
}
//==================================================
// Returns a string giving the status of the name:
// whether the name is defined and, if defined as a
// range, if the range is valid.
//==================================================
xloper * __stdcall check_name(char *name)
{
	xlName R(name);
	char ret_val[50];
	bool ref_ok = R.Refresh();
	bool name_ok = R.IsDefined();

	sprintf(ret_val, "Name:%s, Ref:%s", name_ok ? "OK" : "X", ref_ok ? "OK" : "X");
	cpp_xloper RetVal(ret_val);
	return RetVal.ExtractXloper();
}
//================================================================
// This command function demonstrates a short-coming in the xlSet
// C API function used by xlName::SetValues() to apply values
// from an xltypeMulti xloper to a named worksheet range.
//
// The xlSet function fails when the equivalent area on the active
// sheet contains an array formula, despite the named range being
// on a different sheet.  Example spreadsheet 'Set Array Example.xls'
// demonstrates Excel reporting this error when the menu command
// "Set TestRange values" is run.
//
// This behaviour occurs even when the sheet name is included in
// the range name.
//================================================================
short __stdcall set_values(void)
{
	xlName R("!TestRange");

	if(!R.IsRefValid())
		return 0;

	cpp_xloper Values((WORD)3, (WORD)3); // array of undetermined type

	for(int i = 0; i < 9; i++)
		Values.SetArrayElement((DWORD)i, i);

	R.SetValues(Values);
	return 1;
}
