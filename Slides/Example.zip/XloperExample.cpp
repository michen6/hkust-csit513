#include <windows.h>
#include "XllAddIn.h"
#include <iostream>

using namespace std;

xloper * __stdcall XloperExample (
   xloper *Xloper1,
   xloper *Xloper2,
   xloper *Xloper3
   )
{
	WORD cols,rows;
	double sum = 0;
	char *text;
	cpp_xloper arg1(Xloper1);
	if (arg1.IsRef()) {
		/*
		double *d_array = coerce_to_double_array(Xloper1,-999999,cols,rows);
		int size = cols * rows;
		for (; size--; d_array++) {
			sum = sum + *d_array;
		}
		cpp_xloper retval(sum);
		return retval.ExtractXloper(true);
		*/
		xloper ret_val;
		if(!coerce_xloper(Xloper1, ret_val, xltypeMulti)) {
			return Xloper2;
		}
		cpp_xloper mtype(&ret_val);
		mtype.GetArrayElement(2,2,text);
		cpp_xloper retfinal(text);
		return retfinal.ExtractXloper(true);
	} else {
		return Xloper2;
	}
}