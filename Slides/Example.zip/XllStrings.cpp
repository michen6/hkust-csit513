//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples functions that manipulate text strings.
//============================================================================
//============================================================================

#include <windows.h>

#include "XllAddIn.h"

//========================================================
short __stdcall count_char(char *text, short ch)
{
	if(!text || ch <= 0 || ch > 255)
		return 0;

	short count = 0;

	while(*text)
		if(*text++ == ch)
			count++;

	return count;
}
//========================================================
void __stdcall replace_mask(char *text, char *old_chars, xloper *op_new_chars)
{
	if(!text || !old_chars)
		return;

	char *p_old, *p;

	if((op_new_chars->xltype & (xltypeMissing | xltypeNil)))
	{
// Remove all occurances of all characters in old_chars
		for(; *text; text++)
		{
			p_old = old_chars;

			for(;*p_old;)
			{
				if(*text == *p_old++)
				{
					p = text;
					do
					{
						*p = p[1]; 
					}
					while (*(++p));
				}
			}
		}
		return;
	}

// Substitute all occurances of old chars with corresponding new
	if(op_new_chars->xltype != xltypeStr
	|| (char)strlen(old_chars) != op_new_chars->val.str[0])
		return;

	char *p_new;

	for(; *text; text++)
	{
		p_old = old_chars;
		p_new = op_new_chars->val.str;

		for(; *p_old; p_old++, p_new++)
		{
			if(*text == *p_old)
			{
				*text = *p_new;
				break;
			}
		}
	}
}
//========================================================
void __stdcall reverse_text(char *text)
{
	strrev(text);
}
//========================================================
short __stdcall find_first(char *text, char *search_text)
{
	if(!text || !search_text)
		return 0;

	char *p = strpbrk(text, search_text);

	if(!p)
		return 0;

	return 1 + p - text;
}
//========================================================
short __stdcall find_first_excluded(char *text, char *search_text)
{
	if(!text || !search_text)
		return 0;

	for(char *p = text; *p; p++)
		if(!strchr(search_text, *p))
			return 1 + p - text;

	return 0;
}
//========================================================
short __stdcall find_last(char *text, short ch)
{
	if(!text || ch <= 0 || ch > 255)
		return 0;

	char *p = strrchr(text, (char)ch);

	if(!p)
		return 0;

	return 1 + p - text;
}
//========================================================
xloper * __stdcall compare_text(char *Atext, char *Btext, xloper *op_is_case_sensitive)
{
	static xloper ret_oper = {0, xltypeNum};

	if(!Atext || !Btext)
		return p_xlErrValue;

// Case-sensitive by default
	bool case_sensitive = (op_is_case_sensitive->xltype == xltypeBool
		 && op_is_case_sensitive->val._bool == 1);

	if(!case_sensitive)
		ret_oper.val.num = stricmp(Atext, Btext);
	else
		ret_oper.val.num = strcmp(Atext, Btext);

	return &ret_oper;
}
//========================================================
xloper * __stdcall compare_nchars(char *Atext, char *Btext, short n_chars, xloper *op_is_case_sensitive)
{
	static xloper ret_oper = {0, xltypeNum};

	if(!Atext || !Btext || n_chars <= 0 || n_chars > 255)
		return p_xlErrValue;

// Case-sensitive by default
	bool case_sensitive = (op_is_case_sensitive->xltype == xltypeBool
		 && op_is_case_sensitive->val._bool == 1);

	if(!case_sensitive)
		ret_oper.val.num = strnicmp(Atext, Btext, n_chars);
	else
		ret_oper.val.num = strncmp(Atext, Btext, n_chars);

	return &ret_oper;
}
//====================================================================
#define MAX_CONCAT_CELLS	100
#define MAX_CONCAT_LENGTH	40000

//====================================================================
xloper * __stdcall concat(xloper *inputs, xloper *p_delim, xloper *p_max_len, xloper *p_num_decs)
{
	cpp_xloper Inputs(inputs);

	if(Inputs.IsType(xltypeMissing | xltypeNil))
		return p_xlErrValue;

	char delim = (p_delim->xltype == xltypeStr) ? p_delim->val.str[1] : ',';
	long max_len = (p_max_len->xltype == xltypeNum) ? (long)p_max_len->val.num : 255l;
	long num_decs = (p_num_decs->xltype == xltypeNum) ? (long)p_num_decs->val.num : -1;
	char *buffer = (char *)calloc(MAX_CONCAT_LENGTH, sizeof(char));
	char *p;
	cpp_xloper Rounding(num_decs);
	long total_length = 0;

	DWORD size;

	Inputs.GetArraySize(size);

	if(size > MAX_CONCAT_CELLS)
		size = MAX_CONCAT_CELLS;

	for(DWORD i = 0; i < size;)
	{
		if(num_decs >= 0 && num_decs < 16
		&& Inputs.GetArrayElementType(i) == xltypeNum)
		{
			xloper *p_op = Inputs.GetArrayElement(i);
			Excel4(xlfRound, p_op, 2, p_op, &Rounding);
		}
		Inputs.GetArrayElement(i, p);

		if(p)
		{
			if((total_length += strlen(p)) < MAX_CONCAT_LENGTH)
				strcat(buffer, p);

			free(p);
		}

		if(++i < size)
			buffer[total_length] = delim;

		if(++total_length > max_len)
		{
			buffer[max_len] = 0;
			break;
		}
	}
	cpp_xloper RetVal(buffer);
	free(buffer);
	return RetVal.ExtractXloper(false);
}
//====================================================================
xloper * __stdcall parse(char *input, xloper *p_delim, xloper *p_numeric, xloper *p_empty)
{
	if(*input == 0)
		return p_xlErrValue;

	cpp_xloper Caller;
	Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();

	if(!Caller.IsType(xltypeSRef | xltypeRef))
		return NULL; // return NULL in case was not called by Excel

	char delimiter = (p_delim->xltype == xltypeStr && p_delim->val.str[0]) ? p_delim->val.str[1] : ',';

	char *p = input;
	WORD count = 1;

	for(;*p;)
		if(*p++ == delimiter)
			++count;

	cpp_xloper RetVal;

	RetVal.SetTypeMulti(1, count);

// Can't use strtok as it ignores empty fields

	char *p_last = input;
	WORD i = 0;
	double d;

	bool numeric = (p_numeric->xltype == xltypeBool && p_numeric->val._bool == 1);
	bool empty_val = (p_empty->xltype & xltypeMissing) == 0;

	while(i < count)
	{
		if((p = strchr(p_last, (int)delimiter)))
			*p = 0;

		if((!p && *p_last) || p > p_last)
		{
			if(numeric)
			{
				d = atof(p_last);
				RetVal.SetArrayElement(0, i, d);
			}
			else
				RetVal.SetArrayElement(0, i, p_last);
		}
		else if(empty_val) // empty field value
		{
			RetVal.SetArrayElement(0, i, p_empty);
		}

		i++;

		if(!p)
			break;

		p_last = p + 1;
	}
	return RetVal.ExtractXloper(false);
}
//====================================================================
