#include <windows.h>
#include <stdio.h>
#include <math.h>

#include "XllAddIn.h"
#include "XllNames.h"

short __stdcall IsBusinessDay (
   long date,
   const char *holiday_centers
   )
{
	return 1;
}

//============================================================================
 xloper * __stdcall getDllName(void)
{
	static xloper dll_name;

	int xl4 = Excel4(xlGetName, &dll_name, 0);

	if(xl4 || dll_name.xltype != xltypeStr)
		return NULL;

// Make a copy of the string (needs to be freed by the caller)

	size_t len = (BYTE)dll_name.val.str[0];
	char *name = (char *)malloc(len + 1);

	memcpy(name, dll_name.val.str, len + 1);

// Now the original string has been copied Excel can free it.
	Excel4(xlFree, 0, 1, &dll_name);
// Now reuse the XLOPER for the new string.
    dll_name.val.str = name;
// Tell Excel to call back into the DLL to free the string
// memory after it has copied out the return value.
    dll_name.xltype     = xltypeStr | xlbitDLLFree;

    return &dll_name;
}
