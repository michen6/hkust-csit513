//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains miscellaneous examples relating to the use
// of the C API accessed via the Excel4() and Excel4v() functions.
//============================================================================
//============================================================================
#include <windows.h>
#include <stdio.h>
#include <math.h>

#include "XllAddIn.h"
#include "XllNames.h"

//============================================================================
char *Excel4_err_msg(int err_num)
{
	switch(err_num)
	{
	case xlretAbort:	return "XL4: macro halted";
	case xlretInvXlfn:	return "XL4: invalid function number";
	case xlretInvCount:	return "XL4: invalid number of arguments";
	case xlretInvXloper: return "XL4: invalid oper structure";
	case xlretStackOvfl: return "XL4: stack overflow";
	case xlretUncalced:	return "XL4: uncalced cell";
	case xlretFailed:	return "XL4: command failed";

	default:
		return NULL;
	}
}
//============================================================================
xloper * __stdcall XL4(int xlfn, xloper *arg0, xloper *arg1,
					   xloper *arg2, xloper *arg3, xloper *arg4,
					   xloper *arg5, xloper *arg6, xloper *arg7,
					   xloper *arg8, xloper *arg9, xloper *arg10,
					   xloper *arg11, xloper *arg12, xloper *arg13,
					   xloper *arg14, xloper *arg15, xloper *arg16,
					   xloper *arg17, xloper *arg18)
{
	xloper *arg_array[19];
	static xloper ret_xloper;

// Fill in array of pointers to the xloper arguments ready for the call
// to Excel4v()
	arg_array[0] = arg0;
	arg_array[1] = arg1;
	arg_array[2] = arg2;
	arg_array[3] = arg3;
	arg_array[4] = arg4;
	arg_array[5] = arg5;
	arg_array[6] = arg6;
	arg_array[7] = arg7;
	arg_array[8] = arg8;
	arg_array[9] = arg9;
	arg_array[10] = arg10;
	arg_array[11] = arg11;
	arg_array[12] = arg12;
	arg_array[13] = arg13;
	arg_array[14] = arg14;
	arg_array[15] = arg15;
	arg_array[16] = arg16;
	arg_array[17] = arg17;
	arg_array[18] = arg18;

// Find the last non-missing argument
	int i;
	for(i = 19; --i >= 0;)
		if(arg_array[i]->xltype != xltypeMissing)
			break;

// Call the function
	int retval = Excel4v(xlfn, &ret_xloper,	i + 1, arg_array);

	if(retval != xlretSuccess)
	{
// If the call to Excel4v() failed, return a string explaining why
// and tell Excel to call back into the DLL to free the memory about
// to be allocated for the return string.
		ret_xloper.xltype = xltypeStr | xlbitDLLFree;
		ret_xloper.val.str = new_xlstring(Excel4_err_msg(retval));
	}
	else
	{
// Tell Excel Excel to free up memory that it might have allocated for
// the return value.
		ret_xloper.xltype |= xlbitXLFree;
	}
	return &ret_xloper;
}
//============================================================================
xloper * __stdcall Excel4_match(xloper *p_lookup_value, xloper *p_lookup_array, int match_type)
{
	static xloper match_retval = {0, xltypeInt};
	xloper match_type_oper;

// Convert the integer argument into an xloper so that a pointer
// to this can be passed to Excel4()
	match_type_oper.val.w = match_type;

	int xl4 = Excel4(
		xlfMatch,		// 1st arg: the function to be called
		&match_retval,	// 2nd arg: ptr to return value
		3,			// 3rd arg: number of subsequent args
		p_lookup_value,	// fn arg1
		p_lookup_array,	// fn arg2
		&match_type_oper);// fn arg3

// Test the return value of Excel4()
	if(xl4 != xlretSuccess)
	{
		match_retval.xltype = xltypeErr;
		match_retval.val.err = xlerrValue;
	}
	else
	{
// Tell Excel to free up memory that it might have allocated for
// the return value.
		match_retval.xltype |= xlbitXLFree;
	}
	return &match_retval;
}
//============================================================================
xloper * __stdcall cppExcel4_match(xloper *p_lookup_value, xloper *p_lookup_array, int match_type)
{
	cpp_xloper RetVal;
	cpp_xloper match_type_oper(match_type);

	Excel4(xlfMatch, &RetVal, 3, p_lookup_value, p_lookup_array, &match_type_oper);

	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_cell(xloper *pRef, int arg_num)
{
	cpp_xloper Arg(arg_num, 1, 66);
	cpp_xloper RetVal;

	Excel4(xlfGetCell, &RetVal, 2, &Arg, pRef);

	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_document(int arg_num, char *sheet_name)
{
	cpp_xloper Arg1(arg_num, 1, 88);

	if(!Arg1.IsType(xltypeInt))
		return p_xlErrValue;

	cpp_xloper Arg2(sheet_name);
	cpp_xloper RetVal;
	Excel4(xlfGetDocument, &RetVal, 2, &Arg1, &Arg2);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_def(char *DefText, char *DocText, int type)
{
	cpp_xloper Arg1(DefText);
	cpp_xloper Arg2(DocText);
	cpp_xloper Arg3(type, 1, 3);
	cpp_xloper RetVal;

	Excel4(xlfGetDef, &RetVal, 3, &Arg1, &Arg2, &Arg3);

	return RetVal.ExtractXloper(true);
}
//============================================================================
int __stdcall define_new_name(void)
{
// Get the name to be defined from the active cell. First get a
// reference to the active cell.  No need to evaluate it, as call
// to xlcDefineName will try to convert contents of cell to a
// string and use that.

	cpp_xloper Name;
	int xl4 = Excel4(xlfActiveCell, &Name, 0);
	Name.SetExceltoFree();

	if(!xl4 && !Name.IsType(xltypeErr))
		Excel4(xlcDefineName | xlPrompt, 0, 1, &Name);

	return 1;
}
//============================================================================
xloper * __stdcall get_formula(xloper *p_ref)
{
	cpp_xloper RetVal;
	Excel4(xlfGetFormula, &RetVal, 1, p_ref);
// Extract and return the xloper, using Excel to free memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_name(char *name, xloper *p_info_type)
{
	cpp_xloper Arg1(name);
	cpp_xloper RetVal;
	int retval = Excel4(xlfGetName, &RetVal, 1, &Arg1);//, p_info_type);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_note(long row, long column)
{
// Create a simple single-cell reference to a cell on the current sheet
	cpp_xloper Arg((WORD)row, (WORD)row, (BYTE)column, (BYTE)column);
	cpp_xloper RetVal;
	Excel4(xlfGetNote, &RetVal, 1, &Arg);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_window(int arg_num, char *window_name)
{
	cpp_xloper Arg1(arg_num, 1, 31);

	if(!Arg1.IsType(xltypeInt))
		return p_xlErrValue;

	cpp_xloper Arg2(window_name);
	cpp_xloper RetVal;
	Excel4(xlfGetWindow, &RetVal, 2, &Arg1, &Arg2);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_workbook(int arg_num, char *book_name)
{
	cpp_xloper Arg1(arg_num, 1, 38);

	if(!Arg1.IsType(xltypeInt))
		return p_xlErrValue;

	cpp_xloper Arg2(book_name);
	cpp_xloper RetVal;
	Excel4(xlfGetWorkbook, &RetVal, 2, &Arg1, &Arg2);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall name_array(char *WorkbookName, int NameType, char *Mask)
{
	cpp_xloper Arg1(WorkbookName);
	cpp_xloper Arg2(NameType, 1, 3);
//	cpp_xloper Arg3(Mask);
	cpp_xloper RetVal;

//	int xl4 = Excel4(xlfNames, &RetVal, 0);
	int xl4 = Excel4(xlfNames, &RetVal, 1, &Arg1);
//	int xl4 = Excel4(xlfNames, &RetVal, 2, &Arg1, &Arg2);
//	int xl4 = Excel4(xlfNames, &RetVal, 3, &Arg1, &Arg2, &Arg3);

// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall selection(int trigger)
{
	cpp_xloper RetVal;
	Excel4(xlfSelection, &RetVal, 0);
// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall xl_windows(int match_type, char *mask)
{
	cpp_xloper Arg1(match_type, 1, 3);
	cpp_xloper Arg2(mask);
	cpp_xloper RetVal;
	Excel4(xlfWindows, &RetVal, 2, &Arg1, &Arg2);
// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall formula_convert(char *p_ref, int from_A1, int to_A1, int abs_rel_type, xloper *p_rel_ref)
{
	cpp_xloper Arg1(p_ref);
	cpp_xloper Arg4(abs_rel_type, 1, 4);
	cpp_xloper RetVal;

	Excel4(xlfFormulaConvert, &RetVal, 5, &Arg1,
		from_A1 ? p_xlTrue : p_xlFalse,
		to_A1 ? p_xlTrue : p_xlFalse,
		&Arg4, p_rel_ref);

// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall text_ref(char *p_ref, int A1_style)
{
	cpp_xloper Arg1(p_ref);
	cpp_xloper RetVal;
	Excel4(xlfTextref, &RetVal, 2, &Arg1, A1_style ? p_xlTrue : p_xlFalse);
// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall ref_text(xloper *p_ref, int A1_style)
{
	cpp_xloper Arg2(A1_style != 0);
	cpp_xloper RetVal;
	Excel4(xlfReftext, &RetVal, 2, p_ref, &Arg2);
// Extract and return xloper. Arg=true to ensure Excel frees memory
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_workspace(int arg_num)
{
	cpp_xloper Arg(arg_num, 1, 72);

	if(!Arg.IsType(xltypeInt))
		return p_xlErrValue;

	cpp_xloper RetVal;
	Excel4(xlfGetWorkspace, &RetVal, 1, &Arg);
	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall get_caller_info(int param)
{
	cpp_xloper Caller;
	cpp_xloper GetCell_param(param);
	cpp_xloper RetVal;

	Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();
	Excel4(xlfGetCell, &RetVal, 2, &GetCell_param, &Caller);

	return RetVal.ExtractXloper(true);
}
//============================================================================
xloper * __stdcall toggle_caller(void)
{
	cpp_xloper Caller;
	Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();

	cpp_xloper RetVal;
	cpp_xloper TypeNum(xltypeNum);
	Excel4(xlCoerce, &RetVal, 2, &Caller, &TypeNum);
	RetVal = ((double)RetVal == 0.0) ? 1.0 : 0.0;
	return RetVal.ExtractXloper();
}
//============================================================================
xloper * __stdcall increment_caller(xloper *trigger)
{
	cpp_xloper Caller;
	Excel4(xlfCaller, &Caller, 0);
	Caller.SetExceltoFree();

	cpp_xloper RetVal;
	cpp_xloper TypeNum(xltypeNum);
	Excel4(xlCoerce, &RetVal, 2, &Caller, &TypeNum);
	RetVal = (double)RetVal + 1.0;
	return RetVal.ExtractXloper();
}
//============================================================================
xloper * __stdcall app_title(xloper *title)
{
	static xloper retval;
	Excel4(xlfAppTitle, &retval, 1, title);
	return &retval;
}
//============================================================================
char *get_dll_name1(void)
{
	cpp_xloper dll_name;
	int xl4 = Excel4(xlGetName, &dll_name, 0);

	dll_name.SetExceltoFree();

	if(xl4 || !dll_name.IsType(xltypeStr))
		return NULL;

// Return a copy of the string (needs to be freed by the caller)
	return (char *)dll_name;
}
//============================================================================
char *get_dll_name2(void)
{
	xloper dll_name;
	int xl4 = Excel4(xlGetName, &dll_name, 0);

	if(xl4 || dll_name.xltype != xltypeStr)
		return NULL;

// Make a copy of the string (needs to be freed by the caller)
	int len = dll_name.val.str[0];
	char *name = (char *)malloc(len + 1);

	memcpy(name, dll_name.val.str + 1, len);
	name[len] = 0;
	Excel4(xlFree, 0, 1, &dll_name);
	return name;
}
//============================================================================
xloper * __stdcall sheet_id(char *sheetname)
{
	cpp_xloper Excel4_ret_val;
	cpp_xloper name(sheetname);

	Excel4(xlSheetId, &Excel4_ret_val, 1, &name);

// Tell destructor to get Excel to free the memory
// pointed to by Excel4_ret_val
	Excel4_ret_val.SetExceltoFree();

	if(Excel4_ret_val.GetType() == xltypeRef)
	{
		cpp_xloper RetVal((double)(&Excel4_ret_val)->val.mref.idSheet);
		return RetVal.ExtractXloper();
	}
	cpp_xloper ErrVal((WORD)xlerrValue);
	return ErrVal.ExtractXloper();
}
//============================================================================
xloper * __stdcall sheet_name(double ID)
{
	static xloper ret_val;
	xloper ID_ref_oper;

	if(ID < 0)
	{
		ID_ref_oper.xltype = xltypeMissing;
	}
	else
	{
		ID_ref_oper.xltype = xltypeRef;
		ID_ref_oper.val.mref.idSheet = (DWORD)ID;
		ID_ref_oper.val.mref.lpmref = NULL;
	}

	Excel4(xlSheetNm, &ret_val, 1, &ID_ref_oper);

	ret_val.xltype |= xlbitXLFree;

	return &ret_val;
}
//============================================================================
xloper * __stdcall sheet_name_cpp(double ID)
{
	cpp_xloper Excel4_ret_val;
	xloper ID_ref_oper;

	if(ID < 0)
	{
		ID_ref_oper.xltype = xltypeMissing;
	}
	else
	{
		ID_ref_oper.xltype = xltypeRef;
		ID_ref_oper.val.mref.idSheet = (DWORD)ID;
		ID_ref_oper.val.mref.lpmref = NULL;
	}

	Excel4(xlSheetNm, &Excel4_ret_val, 1, &ID_ref_oper);

	return Excel4_ret_val.ExtractXloper(true);
}
//============================================================================
bool register_example(void)
{
	cpp_xloper dll_name;
	cpp_xloper function_name("exponent_function");
// 1st B means return a double, 2nd B means take a double arg
	cpp_xloper type_text("BB");
	cpp_xloper worksheet_function_name("MY_EXP");
	cpp_xloper arguments("Exponent");
	cpp_xloper function_type(1);
	cpp_xloper category("My functions");
	cpp_xloper description("Returns e to the power of Exponent");
	cpp_xloper arg1_help("Any number such that |arg1| <= 709");
	cpp_xloper ret_val;

// Get the full path and name of the DLL.
	if(Excel4(xlGetName, &dll_name, 0) != xlretSuccess)
		return false;

// Tell destructor to use Excel to free the string memory when done.
	dll_name.SetExceltoFree();

	int XL4_ret_val = Excel4(xlfRegister,
		&ret_val,
		11, // number of subsequent arguments
		&dll_name,
		&function_name,
		&type_text,
		&worksheet_function_name,
		&arguments,
		&function_type,
		&category,
		p_xlMissing,	// no shortcut
		p_xlMissing,	// no help topic
		&description,
		&arg1_help);

	if(XL4_ret_val)
	{
		cpp_xloper xMessage("Could not register MY_EXP");
		cpp_xloper xInt(2); // Dialog box type.

		Excel4(xlcAlert, NULL, 2, &xMessage, &xInt);
		return false;
	}
	return true;
}
//============================================================================
double __stdcall exponent_function(double arg1)
{
	if(fabs(arg1) > 709) // limit of e^arg1 in IEEE double
		return 0.0;

	return exp(arg1);
}
//============================================================================
double __stdcall function_break_example(xloper *arg)
{
	if(arg->xltype != xltypeNum)
		return -1;

	cpp_xloper Break;

	long l;
	for(l = (long)arg->val.num; --l;)
	{
// Detect a user break attempt but leave it set so that other
// worksheet functions can also detect it
		Excel4(xlAbort, &Break, 0);

		if((bool)Break)
			break;
	}
	return l;
}
//============================================================================
double __stdcall get_stack(void)
{
	xloper retval;

	if(xlretSuccess != Excel4(xlStack, &retval, 0))
		return -1.0;

	return (double)(unsigned short)retval.val.w;
}
//============================================================================
int __stdcall xl_call_version(void)
{
	cpp_xloper Version(XLCallVer()); // returns an integer
	Version.ConvertToString(false); // convert integer to string
	Excel4(xlcAlert, 0, 1, &Version); // display the string
	return 1;
}
//============================================================================
xloper * __stdcall evaluate(xloper p_formula)
{
	cpp_xloper RetVal;
	Excel4(xlfEvaluate, &RetVal, 1, p_formula);
	return RetVal.ExtractXloper(true);
}
//============================================================================
#if USE_CPP_XLOPER
bool excel_using_1904_system(void)
{
	cpp_xloper Using1904; // initialised to xltypeNil
	cpp_xloper Arg(20); // initialised to xltypeInt
	Excel4(xlfGetDocument, &Using1904, 1, &Arg);

	if(Using1904.IsBool() && (bool)Using1904)
		return true;

	return false;
}
#else
// This version is quicker as the creator/destructor
// calls and the overloaded operator calls are not
// required
bool excel_using_1904_system(void)
{
	xloper Using1904;
	xloper Arg;

	Arg.xltype = xltypeInt;
	Arg.val.w = 20;

	Excel4(xlfGetDocument, &Using1904, 1, &Arg);

	if(Using1904.xltype == xltypeBool && Using1904.val._bool == 1)
		return true;

	return false;
}
#endif
//============================================================================
#define DAYS_1900_TO_1904	1462 // = 1-Jan-1904 in 1900 system

int __stdcall worksheet_date_fn(int input_date)
{
	bool using_1904 = excel_using_1904_system();

	if(using_1904)
		input_date += DAYS_1900_TO_1904;

// Do something with the date
	int result = 0; // some_date_fn(input_date);

	if(using_1904)
		result -= DAYS_1900_TO_1904;

	return result;
}
//============================================================================
xloper * __stdcall count_used_cells(int first_row, int last_row, int first_col, int last_col)
{
	if(first_row > last_row || first_col > last_col)
		return p_xlErrValue;

// Adjust inputs to be zero-counted and cast to WORDs and BYTEs.
	WORD fr = (WORD)(first_row - 1);
	WORD lr = (WORD)(last_row - 1);
	BYTE fc = (BYTE)(first_col - 1);
	BYTE lc = (BYTE)(last_col - 1);

	cpp_xloper op(fr, lr, fc, lc);
	cpp_xloper RetVal;

	Excel4(xlfCount, &RetVal, 1, &op);
	return RetVal.ExtractXloper();
}
//============================================================================
xloper * __stdcall count_used_cells2(char *sheetname, int first_row, int last_row, int first_col, int last_col)
{
	if(first_row > last_row || first_col > last_col)
		return p_xlErrValue;

// Adjust inputs to be zero-counted and cast to WORDs and BYTEs.
	WORD fr = (WORD)(first_row - 1);
	WORD lr = (WORD)(last_row - 1);
	BYTE fc = (BYTE)(first_col - 1);
	BYTE lc = (BYTE)(last_col - 1);

	cpp_xloper op(sheetname, fr, lr, fc, lc);
	cpp_xloper RetVal;

	Excel4(xlfCount, &RetVal, 1, &op);
	return RetVal.ExtractXloper();
}
//============================================================================
double __stdcall  C_indirect1(long trigger, long row, long col)
{
	cpp_xloper Result;
	cpp_xloper ResultType(xltypeNum); // Get Excel to try and convert to a f.p. number

// Convert to zero-base and right types for constructor
	WORD r = (WORD)(row - 1);
	BYTE c = (BYTE)(col - 1);

// Create xltypeSref from inputs
	cpp_xloper Source(r, r, c, c);

	if(Excel4(xlCoerce, &Result, 2, &Source, &ResultType))
		return 0.0;

	return (double)Result;
}
//============================================================================
double __stdcall  C_indirect2(long trigger, xloper *p_xopSource)
{
	cpp_xloper Result;
	cpp_xloper ResultType(xltypeNum); // Get Excel to try and convert to a f.p. number

	if(xlretSuccess != Excel4(xlCoerce, &Result, 2, p_xopSource, &ResultType))
		return 0.0;

	return (double)Result;
}
//============================================================================
void show_alert_with_arg(char *msg, char *arg)
{
	if(!msg || !arg)
		return;

	int buffer_size = strlen(msg) + strlen(arg);

	// allocate a big enough buffer for error messages
	char *message = new char[10 + buffer_size];
	sprintf(message, msg, arg);
	message[255] = 0; // truncate if name is too long
	cpp_xloper Message(message);
	Excel4(xlcAlert, 0, 1, &Message);
	delete[] message;
}
//============================================================================
bool get_calling_cell_value(xloper &value)
{
//-----------------------------------------------------------
// Get a reference to the calling cell
//-----------------------------------------------------------
	xloper caller;
	int xl4 = Excel4(xlfCaller, &caller, 0);

	if(xl4) // if xlfCaller failed
		return false;

	if(!(caller.xltype & (xltypeRef | xltypeSRef)))
	{
		Excel4(xlFree, 0, 1, &caller);
		return false;
	}

//-----------------------------------------------------------
// Get the calling cell's value
//-----------------------------------------------------------

	xloper xl_ret_val;

	xl4 = Excel4(xlCoerce, &xl_ret_val, 1, &caller);

	if(xl4)
	{
		Excel4(xlFree, 0, 1, &caller);
		return false;
	}

//-----------------------------------------------------------
// Clone the value and free the Excel-allocated memory
//-----------------------------------------------------------
	value = xl_ret_val;

	if(!clone_xloper(&value))
	{
		Excel4(xlFree, 0, 2, &caller, &xl_ret_val);
		return false;
	}

	Excel4(xlFree, 0, 2, &caller, &xl_ret_val);
	return true;
}
//============================================================================
#define USE_CPP_XLOPER 1

#if USE_CPP_XLOPER

// This function is used as an example of a function where
// allocated memory needs to be freed by the DLL after
// having been returned to Excel.  (See section 7.4)

xloper * __stdcall random_array(int rows, int columns)
{
	int array_size = rows * columns;
	static xloper ret_oper;
	xloper *array;

	if(array_size <= 0)
		return NULL;

	array = (xloper *)malloc(array_size * sizeof(xloper));

	if(array == NULL)
		return NULL;

	for(int i = array_size; --i >= 0;)
		Excel4(xlfRand, array + i, 0); 

// Instruct Excel to call back into DLL to free the memory
	ret_oper.xltype = xltypeMulti | xlbitDLLFree;
	ret_oper.val.array.lparray = array;
	ret_oper.val.array.rows = rows;
	ret_oper.val.array.columns = columns;

	return &ret_oper;
}

#else

xloper * __stdcall random_array(int rows, int columns)
{
	cpp_xloper array((WORD)rows, (WORD)columns);

	if(!array.IsType(xltypeMulti))
		return NULL;

	DWORD array_size;
	array.GetArraySize(array_size);

	for(DWORD i = 0; i < array_size; i++)
		Excel4(xlfRand, array.GetArrayElement(i), 0); 

	return array.ExtractXloper(false);
}

#endif
//============================================================================

