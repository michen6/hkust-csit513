//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file (and header file) contain code examples relating to the
// creation of a background thread in the DLL and the creation and management
// of tasks associated with worksheet cells.  These tasks are run in
// background by the thread.  When tasks are complete the worksheet cells are
// updated under the control of a repeating command function associated with
// this task thread.
//============================================================================
//============================================================================
#include <windows.h>
#include <stdio.h>
#include <time.h>

#include "XllAddIn.h"
#include "XllNames.h"
#include "Background.h"

char *make_unique_name(void);

bool get_calling_cell_value(xloper &value);

#define DEFAULT_THREAD_SLEEP_MS		250
#define THREAD_INACTIVE_SLEEP_MS	1000

int __stdcall long_task_menu_setup(void);
int __stdcall long_task_polling_cmd(void);

TaskList ExampleTaskList(long_task_polling_cmd, 5, long_task_menu_setup); // poll every 5 secs

DWORD __stdcall background_thread_main(void *vp);

//============================================================================
task *NewTask(xloper *arg_array, short num_args)
{
	if(!arg_array || num_args < 1)
		return NULL;

	task *p = (task *)malloc(sizeof(task) + sizeof(xloper) * (num_args - 1));

	xloper *p_op = p->arg_array;

	memcpy(p_op, arg_array, sizeof(xloper) * num_args);

	for(int i = num_args; i--; clone_xloper(p_op++));

	p->break_task = false;
	p->num_args = num_args;
	p->fn_ret_val = *p_xlErrNum; // default 'pending' value

	return p;
}
//============================================================================
void FreeTaskArgs(task *pTask)
{
// Free each arg one at a time and then free the arg array itself.
// The class makes its own copies of strings and arrays that are
// passed to it.

	if(!pTask || !pTask->num_args) // can't do this twice by accident
		return;

	xloper *p = pTask->arg_array;

	for(int i = pTask->num_args; i--; free_xloper(p++, false));

	pTask->num_args = 0;
}
//============================================================================

// TaskList member functions

//============================================================================
//============================================================================
//============================================================================
//
//	THESE FUNCTIONS ARE ONLY CALLED BY THE FOREGROUND THREAD
//
//============================================================================
//============================================================================
//============================================================================
TaskList::TaskList(int (__stdcall * Cmd)(void), short FreqSecs, int (__stdcall * MenuFn)(void))
{
	m_pTail = m_pHead = m_pCurrent = NULL;

	if(!Cmd || FreqSecs < 1 || !MenuFn)
		return;

	InitializeCriticalSection(&m_ListControl);
	InitializeCriticalSection(&m_ThreadControl);

	m_ThreadExitFlagSet = m_SuspendAllFlagSet = false;
	m_ThreadIsCreated = m_ThreadIsRunning = false;

	m_ThreadHandle = 0;
	m_ThreadID = 0;
	m_ThreadSleepMs = DEFAULT_THREAD_SLEEP_MS;

	m_BreakPollingCmdFlag = false;
	PollingCmd = Cmd;
	m_PollingCmdFreqSecs = FreqSecs;

	MenuSetupFn = MenuFn;	
};
//============================================================================
TaskList::~TaskList(void)
{
	if(m_ThreadIsCreated)
		DeleteTaskThread(); // terminates the thread

	DeleteCriticalSection(&m_ThreadControl);
	DeleteCriticalSection(&m_ListControl);
};
//============================================================
bool TaskList::CreateTaskThread(void)
{
	if(m_ThreadIsCreated)
		return true;

// Start the OS thread in an active state, but stop it from
// doing anything for now. Pass this instance of the class
// as a parameter so that background_thread_main() can call
// this instance's own main function, TaskThreadMain
	m_ThreadHandle = CreateThread(NULL, 0, background_thread_main, this, 0, &m_ThreadID);

	if(!m_ThreadHandle)
		return false;

//	m_ThreadIsRunning = false; // should already have this value
	m_ThreadIsCreated = true;

// Set up the custom menu items, tool bar buttons, etc.
	MenuSetupFn(); // set up the menu item from which thread can be controlled

	return true;
}
//============================================================
void TaskList::DeleteTaskThread(void) // exits the thread and reinitialises
{
	if(!m_ThreadIsCreated)
		return;

// Clean up the added menu items, tool bar buttons, etc.
	MenuSetupFn(); // set up the menu item from which thread can be controlled

// Stop the polling command from executing its next cycle
	m_BreakPollingCmdFlag = true;

// First suspend the thread. This takes care of stopping
// the current task.  The thread is still active but will
// not process any tasks
	SuspendTaskThread();

// Tell background thread to return (i.e. exit)
	EnterCriticalSection(&m_ThreadControl);
	m_ThreadExitFlagSet = true;
	LeaveCriticalSection(&m_ThreadControl);

// Wait for the thread to terminate.
	DWORD Code;
	for(;GetExitCodeThread(m_ThreadHandle, &Code) && Code == STILL_ACTIVE; Sleep(10));

// Delete the thread object by releasing the handle
	CloseHandle(m_ThreadHandle);

// Delete all the tasks and free related resources
	DeleteAllTasks();

	m_SuspendAllFlagSet = m_ThreadExitFlagSet = m_ThreadIsCreated = false;
	m_ThreadHandle = 0;
	m_ThreadID = 0;
}
//============================================================
bool TaskList::SuspendTaskThread(void)
{
	if(!m_ThreadIsCreated || !m_ThreadIsRunning)
		return true;

// Stop the polling command from executing its next cycle
	m_BreakPollingCmdFlag = true;

	EnterCriticalSection(&m_ThreadControl);

	m_SuspendAllFlagSet = true;

	LeaveCriticalSection(&m_ThreadControl);

	EnterCriticalSection(&m_ListControl);

	if(m_pCurrent) // need also to break current task execution
		m_pCurrent->break_task = true;

	LeaveCriticalSection(&m_ListControl);

	for(; m_ThreadIsRunning; Sleep(10));

	return true;
}
//============================================================
bool TaskList::ResumeTaskThread(void) // restarts suspended thread
{
	if(!m_ThreadIsCreated)
		return false;
		
	if(m_ThreadIsRunning)
		return true;

	m_SuspendAllFlagSet = false;
	m_ThreadIsRunning = true;

	EnterCriticalSection(&m_ListControl);

	if(m_pCurrent) // need also to also current task execution to resume
		m_pCurrent->break_task = false;

	LeaveCriticalSection(&m_ListControl);

// Restart the polling command cycle
	m_BreakPollingCmdFlag = false;
	PollingCmd();

	return true;
}
//============================================================================
bool TaskList::SetThreadSleepMs(long sleep_ms)
{
	if(sleep_ms < 0)
		return false;

	m_ThreadSleepMs = sleep_ms;
	return true;
}
//============================================================================
bool TaskList::SetPollingSecs(short rpt_secs)
{
	if(rpt_secs < 1)
		return false;

	m_PollingCmdFreqSecs = rpt_secs;
	return true;
}
//============================================================================
//============================================================================
// Task list management
//============================================================================
//============================================================================
void TaskList::GetTaskStats(long &pending, long &done)
{
	pending = done = 0;

	EnterCriticalSection(&m_ListControl);

	for(task *p = m_pHead; p; p = p->next)
	{
		if(p->status == TASK_PENDING)
			pending++;
		else if(p->status & (TASK_READY | TASK_UNCLAIMED | TASK_COMPLETE))
			done++;
	}
	LeaveCriticalSection(&m_ListControl);
}
//============================================================================
void TaskList::ModifyTask(task *p, xloper *arg_array, short num_args)
{
//------------------------------------------
// Free the old arguments and set the new
//------------------------------------------
	FreeTaskArgs(p);

	task *p_new = NewTask(arg_array, num_args);

//------------------------------------------
// Protect the new task from becoming current
// until it's set up and added to the list
//------------------------------------------
	p_new->break_task = true;

//------------------------------------------
// Copy the things that survive
//------------------------------------------
	p_new->caller_name = p->caller_name;
	p_new->fn_ptr = p->fn_ptr;
	p_new->fn_ret_val = p->fn_ret_val;
	p_new->status = TASK_PENDING;

//------------------------------------------
// Remove the old task from the list and free
// the task memory but not the strings pointed
// to within it.
//------------------------------------------
	RemoveTaskFromList(p);

//------------------------------------------
// Add the new task to the end of the list.
//------------------------------------------
	AddTaskToListTail(p_new);

//------------------------------------------
// Enable the task to become current
//------------------------------------------
	p_new->break_task = false;
	return;
}
//============================================================================
task *TaskList::FindTask(char *name)
{
	task *p = m_pHead;

	if(!p)
		return NULL;

	do
	{
		if(strcmp(name, p->caller_name) == 0)
			return p;
	}
	while((p = p->next));

	return NULL;
}
//============================================================================
void TaskList::AddTaskToListTail(task *p)
{
// Need to enter m_ListControl as we may be changing things
// that the background thread is reading.
	EnterCriticalSection(&m_ListControl);

	if(m_pTail) // already something in queue
	{
		m_pTail->next = p;
		p->prev = m_pTail;
		m_pTail = p;
		p->next = NULL;
	}
	else  // this will be the first task to be processed
	{
		m_pTail = m_pHead = p;
		p->prev = p->next = NULL;
	}

	LeaveCriticalSection(&m_ListControl);
}
//============================================================================
bool TaskList::RemoveTaskFromList(task *p)
{
// Need to enter m_ListControl as we may be changing things
// that the background thread is reading or might read.
	EnterCriticalSection(&m_ListControl);

	if(!m_pHead || !p || (m_ThreadIsRunning && p == m_pCurrent))
	{
		LeaveCriticalSection(&m_ListControl);
		return false;
	}

	if(p == m_pHead)
	{
		if(p->next)
		{
			m_pHead = p->next;
			m_pHead->prev = NULL;
		}
		else // was the only thing in the list
		{
			m_pHead = m_pTail = m_pCurrent = NULL;
		}
	}
	else if(p == m_pTail) // will be more than this
	{
		m_pTail = p->prev; // can't be NULL
		m_pTail->next = NULL;
	}
	else  // this will be the first task to be processed
	{
		p->next->prev = p->prev; // } could be NULL if was
		p->prev->next = p->next; // } next to m_pHead or m_pTail
	}

	LeaveCriticalSection(&m_ListControl);
	return true;
}
//============================================================================
bool TaskList::AddNewTask(bool (* fn_ptr)(tag_task *), xloper *arg_array, short num_args)
{
	xlName Caller;
// Create an internal name and apply it to the calling cell
	if(!Caller.NameCaller(NULL))
		return false;

	char *name = Caller.GetName();

// Create a new task and fill in the data
	task *p = NewTask(arg_array, num_args);

	if(!p)
	{
		free(name);
		return false;
	}

	p->caller_name = name; // free when task is deleted
	p->status = TASK_PENDING;
	p->fn_ptr = fn_ptr;

	AddTaskToListTail(p);

	return true;
}
//============================================================================
void TaskList::DeleteTask(task *pTask)
{
	if(!RemoveTaskFromList(pTask))
		return;

	cpp_xloper Name(pTask->caller_name);
	free(pTask->caller_name); // Name has its own copy now

	Excel4(xlfSetName, 0, 1, &Name); // delete the name definition

	FreeTaskArgs(pTask);
	free(pTask);
}
//============================================================================
void TaskList::DeleteAllTasks(void)
{
	if(!m_pHead)
		return;

	task *p = m_pHead, *next_p;

	do
	{
		next_p = p->next;
		DeleteTask(p);
	}
	while((p = next_p));
}
//============================================================================
void TaskList::DeleteUnclaimedTasks(void)
{
	if(!m_pHead)
		return;

	task *p = m_pHead, *next_p;

	do
	{
		next_p = p->next;

		if(p->status == TASK_UNCLAIMED)
			DeleteTask(p);
	}
	while((p = next_p));
}
//============================================================================
void TaskList::BreakCurrentTask(task *p)
{
	if(!m_pCurrent || p != m_pCurrent)
	{
//	No task to break, or m_pCurrent already changed by background thread
		return;
	}
	p->break_task = true; // this may already have been set, but no harm done

// Wait for status to change.  Note that once broken, the background thread
// will move onto next task unless m_SuspendAllFlagSet is also true.  Note
// that status tested is p->status not m_pCurrent->status.  Note that break
// flag is left set so that this task does not become current again till
// we're ready.
	for(;p->status == TASK_CURRENT; Sleep(10));

// Status of task should now be TASK_PENDING again and m_pCurrent will either
// be NULL or point to the next task to be executed after this one.
}
//============================================================================
bool TaskList::ArgsChanged(task *p, xloper *arg_array, short num_args)
{
	if(p->num_args != num_args)
		return true;

	xloper *p1 = p->arg_array, *p2 = arg_array;

	for(int i = num_args; i--;)
		if((p1++)->xltype != (p2++)->xltype)
			return true;

	p1 = p->arg_array;
	p2 = arg_array;

	for(int i = num_args; i--;)
		if(!xlopers_equal(*p1++, *p2++))
			return true;

	return false; // nothing is different
}
//============================================================================
// TaskList::UpdateTask performs 3 functions:
//
// 1. Supplies new new task to list or updates arguments to existing task
//
// 2. Returns current value of task which may be intermediate or final
//
// 3. If no args have changed and and existing task was done, then deletes task
//
//============================================================================
xloper TaskList::UpdateTask(bool (* fn_ptr)(tag_task *), xloper *arg_array, short num_args)
{
	if(!m_ThreadIsCreated || !m_ThreadIsRunning)
		return *p_xlErrNa;

	xloper ret_val; // no need to wrap this in a cpp_xloper

	if(!fn_ptr || !arg_array || num_args < 1)
		return *p_xlErrValue;

	xlName Caller;
	bool name_exists = Caller.SetToCallersName();

	if(name_exists)
	{
// This cell has already a name assigned.  Need to check to see if
// this is an internal name associated with this function
		char *name = Caller.GetName();
		task *p = FindTask(name);
		free(name);

		if(p && fn_ptr == p->fn_ptr) // task exists already for this caller and function
		{
// Set this here as we might destroy p if new args
			ret_val = p->fn_ret_val;

// Check if args have changed since task was scheduled
			if(ArgsChanged(p, arg_array, num_args))
			{
// Stop the task being or becoming current
				p->break_task = true;

				if(p == m_pCurrent) // m_pCurrent changes in background
					BreakCurrentTask(p); // waits for task to break

// destroys p and replaces with modified task, at end of
// list with break_task = false
				ModifyTask(p, arg_array, num_args);
			}
			if(p->status == TASK_UNCLAIMED)
				p->status = TASK_COMPLETE;

			return ret_val;
		}
//	fall through to AddNewTask
	}

	if(!AddNewTask(fn_ptr, arg_array, num_args)) //, Caller))
		return *p_xlFalse;
	else
		return *p_xlTrue;
}
//============================================================================
bool TaskList::SetDoneTasks(void)
{
	char note_txt[50];
	double exec_secs;
	bool need_recalc = false;
	xlName R;
	task *p_temp;

	for(task *p = m_pHead; p;)
	{
		if(p->status != TASK_READY && p->status != TASK_COMPLETE)
		{
			p = p->next;
			continue;
		}

// READY and COMPLETE tasks are flagged as unclaimed.
// This ensures that all orphaned tasks are deleted if, after
// recalculation, they have not been reset to TASK_COMPLETE
// through the action of a worksheet cell recalculation
		p->status = TASK_UNCLAIMED;

// Delete the task if its name no longer corresponds to a
// valid reference
		if(!R.Set(p->caller_name))
		{
			p_temp = p->next;
			DeleteTask(p);
			p = p_temp;
			continue;
		}

		exec_secs = (p->end_clock - p->start_clock) / (double)CLOCKS_PER_SEC;
		sprintf(note_txt, "Time: %.1lfs", exec_secs);
		R.SetNote(note_txt);
		need_recalc = true;
		p = p->next;
	}
	return need_recalc;
}
//============================================================================
//============================================================================
//============================================================================
//
//	THESE FUNCTIONS ARE ONLY CALLED BY THE BACKGROUND THREAD
//
//============================================================================
//============================================================================
//============================================================================
// This function is not part of the class, but is passed as an argument
// to CreateThread() along with a pointer to 'this' so that it can call
// back into the class' TaskThreadMain. 
//============================================================================
DWORD __stdcall background_thread_main(void *vp)
{
	return ((TaskList *)vp)->TaskThreadMain();
}
//============================================================================
void TaskList::GetNextTask(void) // used by background to set m_pCurrent
{
	if(!m_pHead) // list is empty
	{
		m_pCurrent = NULL;
		return;
	}

	EnterCriticalSection(&m_ListControl);

	if(!m_pCurrent)
		m_pCurrent = m_pHead;

	do
	{
		if(m_pCurrent->status == TASK_PENDING && !m_pCurrent->break_task)
			break;

		m_pCurrent = m_pCurrent->next;
	}
	while(m_pCurrent); // look till end of list

	if(m_pCurrent)
		m_pCurrent->status = TASK_CURRENT;

	LeaveCriticalSection(&m_ListControl);
}
//============================================================================
DWORD TaskList::TaskThreadMain(void)
{
	for(;!m_ThreadExitFlagSet;)
	{
		if(!m_ThreadIsRunning)
		{
// Thread has been put into inactive state
			Sleep(THREAD_INACTIVE_SLEEP_MS);
			continue;
		}

		if(m_SuspendAllFlagSet)
		{
			m_ThreadIsRunning = false;
			m_pCurrent = NULL;
			continue;
		}

// Find next task to be executed. Sets m_pCurrent to
// point to the next task, or to NULL if no more to do.
		GetNextTask();

		if(m_pCurrent)
		{
// Execute the current task and time it. Status == TASK_CURRENT
			m_pCurrent->start_clock = clock();
			if(m_pCurrent->fn_ptr(m_pCurrent))
			{
// Task completed sucessfully and is ready to be read out
				m_pCurrent->status = TASK_READY;
			}
			else
			{
// Task was broken or failed so need to re-queue it
				m_pCurrent->status = TASK_PENDING;
			}
			m_pCurrent->end_clock = clock();
		}
		else // nothing to do, so have a little rest
			Sleep(m_ThreadSleepMs);
	}
	return !(STILL_ACTIVE);
}
//============================================================================
//============================================================================
//============================================================================
//============================================================================
//
//  Example interface functions
//
//	These functions and commands work with the TaskList to perform
//	long tasks in background
//
//============================================================================
//============================================================================
//============================================================================
// long_task_example_main() exectues the task and does the work.
// It is only ever called from the background thread.  It is
// required to check the break_task flag regularly to see if the
// foreground thread needs execution to stop.  It is not required
// that the task populates the return value, fn_ret_val, as it does
// in this case.  It could just wait till the final result is known.
//============================================================================
bool long_task_example_main(tag_task *pTask)
{
	long limit;

	if(pTask->arg_array[0].xltype != xltypeNum
	|| (limit = (long)pTask->arg_array[0].val.num) < 1)
		return false;

	pTask->fn_ret_val.xltype = xltypeNum;
	pTask->fn_ret_val.val.num = 0;

	for(long i = 1; i <= limit; i++)
	{
		if(i % 1000)
		{
			if(pTask->break_task)
				return false;

			Sleep(0);
		}
		pTask->fn_ret_val.val.num = (double)i;
	}
	return true;
}
//============================================================================
// long_task_interface() is a worksheet function called
// directly by Excel from the foreground thread.  It is only
// required to check arguments and call ExampleTaskList.UpdateTask()
// which returns either an error, or the intermediate or final value
// of the calculation.  UpdateTask() errors can be returned directly
// or, as in this case, the function can return the current
// (previous) value of the calling cell.  This function is registered
// with Excel as a volatile macro sheet function.
//============================================================================
xloper * __stdcall long_task_interface(xloper *arg)
{
	if(called_from_paste_fn_dlg())
		return p_xlErrNa;

	if(arg->xltype != xltypeNum || arg->val.num < 1)
		return p_xlErrValue;

	xloper arg_array[1]; // only 1 argument in this case
	static xloper ret_val;

// UpdateTask makes deep copies of all the supplied arguments
// so passing in an array of shallow copies is safe.
	arg_array[0] = *arg;

// As there is only one argument in this case, we could instead
// simply pass a pointer to this instead of creating the array
	ret_val = ExampleTaskList.UpdateTask(long_task_example_main,
			arg_array, 1);

	if(ret_val.xltype == xltypeErr)
	{
		switch(ret_val.val.err)
		{
		// the arguments were not valid
		case xlerrValue:
			break;

		// task has never been completed and is now pending or current
		case xlerrNum:
			break;

		// the thread is inactive
		case xlerrNA:
			break;
		}

// Return the existing cell value.
		get_calling_cell_value(ret_val);
	}
	ret_val.xltype |= xlbitDLLFree; // memory to be freed by the DLL
	return &ret_val;
}
//============================================================================
#define SECS_PER_DAY		(60.0 * 60.0 * 24.0)
//============================================================================
// This command function is called by Excel directly or indirectly
// in the foreground DLL thread.
//============================================================================
int __stdcall long_task_polling_cmd(void)
{
	if(ExampleTaskList.m_BreakPollingCmdFlag)
		return 0; // return without rescheduling next call

// Run through the list of tasks setting TASK_READY tasks to
// TASK_UNCLAIMED. Tasks still unclaimed after recalculation are
// assumed to be orphaned and deleted by DeleteUnclaimedTasks().
	bool need_racalc = ExampleTaskList.SetDoneTasks();

//	if(need_racalc) // Commented out in this example
	{
// Cause Excel to recalculate.  This forces all volatile fns to be
// re-evaluated, including the long task functions, which will then
// return the most up-to-date values.  This also causes status of
// tasks to be changed to TASK_COMPLETE from TASK_UNCLAIMED.
		Excel4(xlcCalculateNow, NULL, 0);

// Run through the list of tasks again to clean up unclaimed tasks
		ExampleTaskList.DeleteUnclaimedTasks();
	}

// Reschedule the command to repeat in m_PollingCmdFreqSecs seconds.
	cpp_xloper Now;
	Excel4(xlfNow, &Now, 0);
	cpp_xloper ExecTime((double)Now +
			ExampleTaskList.GetPollingSecs() / SECS_PER_DAY);

// Use command name as given to Excel in xlfRegister 4th arg
	cpp_xloper CmdName("LongTaskPoll"); // as registered with Excel
	cpp_xloper RetVal;

	int xl4 = Excel4(xlcOnTime, &RetVal, 2, &ExecTime, &CmdName);
	RetVal.SetExceltoFree();

	if(xl4 || RetVal.IsType(xltypeErr))
	{
		cpp_xloper ErrMsg("Can't reschedule long task polling cmd");
		Excel4(xlcAlert, 0, 1, &ErrMsg);
	}
	return 1;
}
//============================================================================
// This command function could be called by Excel directly or indirectly
// in the foreground DLL thread.
//============================================================================
int __stdcall long_task_toggle_cmd(void)
{
	if(!ExampleTaskList.IsThreadCreated())
		return 0;

	if(ExampleTaskList.IsThreadRunning())
		ExampleTaskList.SuspendTaskThread();
	else
		ExampleTaskList.ResumeTaskThread();

	return 1;
}
//============================================================================

// Long Task Thread Configuration Dialog

#define LTCD_NUM_ROWS	18

cpp_xloper LongTaskConfigDlg[LTCD_NUM_ROWS * CAPI_DLG_COLUMNS] =
{
	"", "", "", 490, 160, "Long Task Thread Configuration", "", // 
	1, 50, 120, 90, "", "OK", "", // Default OK button
	2, 150, 120, 90, "", "Cancel", "", // Cancel button
	3, 250, 120, "", "", "&Suspend", "", // OK button
	3, 350, 120, "", "", "&Kill thread", "", // OK button
	5, 20, 13, "", "", "", "", // Static text
	5, 20, 33, "", "", "Thread sleep time (ms)", "", // Static text
	5, 20, 53, "", "", "Command repeat time (s)", "", // Static text
	5, 20, 73, "", "", "Thread is initialised", "", // Static text
	5, 20, 93, "", "", "Thread is running", "", // Static text
	5, 300, 73, "", "", "Pending tasks:", "", // Static text
	5, 300, 93, "", "", "Done tasks:", "", // Static text
	5, 400, 73, "", "", "", "", // Static text
	5, 400, 93, "", "", "", "", // Static text
	7, 200, 30, 75, "", "", "", // Integer edit box
	7, 200, 50, 75, "", "", "", // Integer edit box
	213, 200, 73, "", "", "", "", // Check box
	213, 200, 93, "", "", "", "", // Check box
};

// Rows corresponding to the elements in the dialog box
enum
{
	LTCD_TOP,
	LTCD_OK,
	LTCD_CANCEL,
	LTCD_SUSP_REST,
	LTCD_KILL,
	LTCD_THREAD_ID_TXT,
	LTCD_THREAD_SLEEP_MS_TXT,
	LTCD_CMD_RPT_SECS_TXT,
	LTCD_IS_CREATED_TXT,
	LTCD_IS_RUNNING_TXT,
	LTCD_PENDING_TASKS_TXT,
	LTCD_DONE_TASKS_TXT,
	LTCD_PENDING_TASKS,
	LTCD_DONE_TASKS,
	LTCD_THREAD_SLEEP_MS,
	LTCD_CMD_RPT_SECS,
	LTCD_IS_CREATED,
	LTCD_IS_RUNNING,
};

//============================================================================
// This command function is called by Excel directly or indirectly
// in the foreground DLL thread.
//============================================================================
int __stdcall long_task_config_cmd(void)
{
	if(!ExampleTaskList.IsThreadCreated())
		return 0;
	
// Create an array of xlopers (within a cpp_xloper) from the array of cpp_xlopers
	cpp_xloper DialogDef((WORD)LTCD_NUM_ROWS, (WORD)CAPI_DLG_COLUMNS, LongTaskConfigDlg);

// Set up the thread ID text field
	char id_text[30];
	sprintf(id_text, "Thread ID: 0x%08x", ExampleTaskList.GetThreadId());
	DialogDef.SetArrayElement((WORD)LTCD_THREAD_ID_TXT, (WORD)CAPI_DLG_TEXT, id_text);

	int xl4, item_num, temp;
	bool keep_looping = true;
	xloper ret_val;
	long pending, done;

	do
	{
// Set up the thread initialisation status field
		DialogDef.SetArrayElement((WORD)LTCD_IS_CREATED, (WORD)CAPI_DLG_VALUE, ExampleTaskList.IsThreadCreated());

// Set up the thread sleep ms and polling command repeat secs value fields
		DialogDef.SetArrayElement((WORD)LTCD_THREAD_SLEEP_MS, (WORD)CAPI_DLG_VALUE, (int)ExampleTaskList.GetThreadSleepMs());
		DialogDef.SetArrayElement((WORD)LTCD_CMD_RPT_SECS, (WORD)CAPI_DLG_VALUE, (int)ExampleTaskList.GetPollingSecs());

// Set the text on the suspend/restore button and the value of the checkbox
		DialogDef.SetArrayElement((WORD)LTCD_SUSP_REST, (WORD)CAPI_DLG_TEXT, ExampleTaskList.IsThreadRunning() ? "&Suspend" : "&Activate");
		DialogDef.SetArrayElement((WORD)LTCD_IS_RUNNING, (WORD)CAPI_DLG_VALUE, ExampleTaskList.IsThreadRunning());

// Set the text on the suspend/restore button and the value of the checkbox
		ExampleTaskList.GetTaskStats(pending, done);
		DialogDef.SetArrayElement((WORD)LTCD_PENDING_TASKS, (WORD)CAPI_DLG_TEXT, (int)pending);
		DialogDef.SetArrayElement((WORD)LTCD_DONE_TASKS, (WORD)CAPI_DLG_TEXT, (int)done);

// Restrict user input to the dialog and then display it
		Excel4(xlcDisableInput, 0, 1, p_xlTrue);
		xl4 = Excel4(xlfDialogBox, &ret_val, 1, &DialogDef);

		if(xl4 || (ret_val.xltype == xltypeBool && ret_val.val._bool == 0)
		|| !ExampleTaskList.IsThreadCreated())
			break;

// Process the input from the dialog by reading the 7th column of the returned array.
// 7th column (CAPI_DLG_VALUE) of top row contains offset of selected button as a double.

		item_num = (short)ret_val.val.array.lparray[CAPI_DLG_VALUE].val.num;

		switch(item_num)
		{
		case LTCD_SUSP_REST:
		// Toggle the thread state (and the text on the button) then fall
		// trough and check the values of the input fields
			if(ExampleTaskList.IsThreadRunning())
				ExampleTaskList.SuspendTaskThread();
			else
				ExampleTaskList.ResumeTaskThread();

		// Process the LTCD_THREAD_SLEEP_MS and LTCD_CMD_RPT_SECS fields
		case LTCD_OK:
			temp = (short)ret_val.val.array.lparray
				[LTCD_THREAD_SLEEP_MS * CAPI_DLG_COLUMNS + CAPI_DLG_VALUE].val.num;

			if(temp != ExampleTaskList.GetThreadSleepMs())
				ExampleTaskList.SetThreadSleepMs(temp);

			temp = (short)ret_val.val.array.lparray
				[LTCD_CMD_RPT_SECS * CAPI_DLG_COLUMNS + CAPI_DLG_VALUE].val.num;

			if(temp != ExampleTaskList.GetPollingSecs())
				ExampleTaskList.SetPollingSecs(temp);

			keep_looping = false;
			break;

		case LTCD_KILL:
		// Kill the thread and disable everything except the
		// OK button.  Redisplay the dialog one last time to
		// show the user that this has all been done.
			ExampleTaskList.DeleteTaskThread();

			for(WORD i = LTCD_CANCEL; i <= LTCD_CMD_RPT_SECS; i++)
			{
				DialogDef.GetArrayElement(i, (WORD)CAPI_DLG_ITEM, item_num);
				item_num = 200 + (item_num % 100);
				DialogDef.SetArrayElement(i, (WORD)CAPI_DLG_ITEM, item_num);
			}
			break;
		}

// Free the array that Excel returned
		Excel4(xlFree, 0, 1, &ret_val);
		ret_val.xltype = xltypeMissing; // safe to call xlFree on this again
	}
	while(keep_looping);

// Re-enable user input to Excel
	Excel4(xlcDisableInput, 0, 1, p_xlFalse);
	Excel4(xlFree, 0, 1, &ret_val);
	return 1;
}
//============================================================================
// This command function is called by Excel directly or indirectly
// in the foreground DLL thread.  This function can itself be exported as
// an Excel command, if required.
//============================================================================
int __stdcall long_task_menu_setup(void)
{
	static bool set_up = true;

	if(!ExampleTaskList.IsThreadCreated())
		return 0;

//----------------------------------------------------------------
// Set up a menu item at the bottom of the Tools menu on
// the worksheet menu bar.
//----------------------------------------------------------------
	cpp_xloper BarNum(10); // the worksheet menu bar
	cpp_xloper Menu("Tools");

// The menu item text as it appears in the menu and the cmd name
// as defined with 4th arg of xlfRegister
	char *menu_text[2] = {"Th&read config",	"LongTaskConfig"};

	if(set_up)
	{
		cpp_xloper CmdRef((WORD)1, (WORD)2, menu_text); // 1 row, 2 columns
		Excel4(xlfAddCommand, 0, 3, &BarNum, &Menu, &CmdRef);
	}
	else
	{
		cpp_xloper Cmd(menu_text[0]); // just the menu item text
		Excel4(xlfDeleteCommand, 0, 3, &BarNum, &Menu, &Cmd);
	}

//----------------------------------------------------------------
// Toggle the function from setting up the menu item to removing it
//----------------------------------------------------------------
	set_up = !set_up;

	return 1;
}
//============================================================================
