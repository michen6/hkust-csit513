//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
#ifndef _NAMES_H
#define _NAMES_H

#ifndef _CPP_XLOPER_H
#include "cpp_xloper.h"
#endif


//-------------------------------------------------------------------
//-------------------------------------------------------------------
// C++ class that encapsulates Excel named range handling using the
// C API
//-------------------------------------------------------------------
//-------------------------------------------------------------------

class xlName
{
public:
//-------------------------------------------------------------------
// constructors & destructor
//-------------------------------------------------------------------
	xlName():m_Defined(false),m_RefValid(false),m_Worksheet(false){}
	xlName(char *name) {Set(name);} // Reference to existing range
	~xlName() {Clear();}

// Copy constructor uses operator= function
	xlName(const xlName & source) {*this = source;}

//-------------------------------------------------------------------
// Overloaded operators
//-------------------------------------------------------------------
// Object assignment operator
	xlName& operator=(const xlName& source);

//-------------------------------------------------------------------
// Assignment operators place values in cell(s) that range refers to.
// Cast operators retrieve values or assign nil if range is not valid
// or conversion was not possible.  Casting to char * will return
// dynamically allocated memory that the caller must free.  Casting
// to xloper can also assign memory that caller must free.
//-------------------------------------------------------------------

	void operator=(int);
	void operator=(bool b);
	void operator=(double);
	void operator=(WORD e);
	void operator=(char *);
	void operator=(xloper *); // same type as passed-in xloper
	void operator=(VARIANT *); // same type as passed-in Variant
	void operator=(xl_array *array);
	void operator+=(double);
	void operator++(void) {operator+=(1.0);}
	void operator--(void) {operator+=(-1.0);}
	operator int(void);
	operator bool(void);
	operator double(void);
	operator char *(void); // DLL-allocated copy, caller must free

	bool IsDefined(void) {return m_Defined;}
	bool IsRefValid(void) {return m_RefValid;}
	bool IsWorksheetName(void) {return m_Worksheet;}
	char *GetDef(void); // get defintion as string (caller must free)
	char *GetName(void); // returns a copy that the caller must free
	bool GetValues(cpp_xloper &Values); // range contents as xltypeMulti
	bool SetValues(cpp_xloper &Values);
	bool NameIs(char *name);
	bool Refresh(void); // refreshes state of name and defn
	bool SetToRef(xloper *, bool internal); // ref's name if it exists
	bool SetToCallersName(void); // set to caller's name if it exists
	bool NameCaller(char *name); // create internal name for caller
	bool Set(char *name); // Create a reference to an existing range
	bool Define(xloper *p_defintion, bool in_dll);
	bool Define(char *name, xloper *p_defintion, bool in_dll);
	void Delete(void); // Delete name and free instance resources
	void Clear(void); // Clear instance memory but don't delete name
	void SetNote(char *text); // Doesn't work - might be C API bug
	char *GetNote(void);

protected:
	bool m_Defined; // Name has been defined
	bool m_RefValid; // Name's defintion (if a ref) is valid
	bool m_Worksheet; // Name is worksheet name, not internal to DLL
	cpp_xloper m_RangeRef;
	cpp_xloper m_RangeName;
};

//-------------------------------------------------------------------
//-------------------------------------------------------------------
// Internal name list management functions

bool add_name_record(void *fn_ptr, xlName &Range);
int __stdcall delete_all_xll_names(void);
void *find_name_record_fn_ptr(xlName &Range);
int __stdcall clean_xll_name_list(void);
int __stdcall delete_all_xll_names(void);

//-------------------------------------------------------------------
//-------------------------------------------------------------------

#endif