//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples that demonstrate some of the possible
// uses of the BigData xloper (xltypeBigData).
//============================================================================
//============================================================================
#include <windows.h>

#include "XllAddIn.h"

//=============================================================
int bin_name(char *name, int create, void *data, long len)
{
	if(!name) 
		return 0;

	cpp_xloper Name(name);

	if(create)
	{
		if(!data || !len)
			return 0;

		xloper big;

		big.xltype = xltypeBigData;
		big.val.bigdata.h.lpbData = (unsigned char *)data;
		big.val.bigdata.cbData = len;

		if(Excel4(xlDefineBinaryName, 0, 2, &Name, &big))
			return 0;
	}
	else
	{
		Excel4(xlDefineBinaryName, 0, 1, &Name);
	}
	return 1;
}
//=============================================================
int __stdcall bin_exists(char *name)
{
	if(!name)
		return 0;

	cpp_xloper Name(name);
	xloper big;

	int xl4 = Excel4(xlGetBinaryName, &big, 1, &Name);

	if(xl4 || big.xltype != xltypeBigData)
		return 0;

	return 1;
}
//=============================================================
int get_binary_data(char *name, void * &data, long &len)
{
	if(!name)
		return 0;

	cpp_xloper Name(name);
	xloper big;

	if(Excel4(xlGetBinaryName, &big, 1, &Name)
	|| big.xltype != xltypeBigData)
		return 0;

	len = big.val.bigdata.cbData;
	if(!(data = malloc(len)))
		return 0;

	void *p = GlobalLock(big.val.bigdata.h.hdata);
	memcpy(data, p, len);
	GlobalUnlock(big.val.bigdata.h.hdata);

	return 1;
}
//=============================================================
xloper * __stdcall set_bin_string(char *name, xloper *p_string)
{
	int create = (p_string->xltype == xltypeStr ? 1 : 0);

	if(create)
	{
		long len = p_string->val.str[0] + 1; // Include null
		char *p = p_string->val.str + 1; // Start of string

		if(bin_name(name, create, p, len))
			return p_xlTrue;

		return p_xlErrValue; // couldn't create
	}

	if(bin_name(name, 0, NULL, 0))
		return p_xlErrName; // deleted ok
	else
		return p_xlErrValue; // couldn't delete
}
//=============================================================
xloper * __stdcall get_bin_string(char *name)
{
	void *string;
	long len;

	if(get_binary_data(name, string, len))
	{
// Constructor will truncate if too long
		cpp_xloper RetVal((char *)string);
		return RetVal.ExtractXloper();
	}
	return p_xlErrName;
}