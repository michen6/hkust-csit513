//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
#pragma once
#define _MATRIX_H

#ifndef WORD
#include <windows.h>
#endif

#ifndef _XLOPER_H
#include "xloper.h"
#endif

#define __MATRIX

class d_matrix;

class d_vector
{
	friend d_matrix;
public:
//--------------------------------------------------------------------
// constructors
//--------------------------------------------------------------------
	d_vector();
	d_vector(WORD elts);
	d_vector(WORD elts, double *init_data);
	d_vector(d_vector &source);

//--------------------------------------------------------------------
// destructor
//--------------------------------------------------------------------
	~d_vector();

//--------------------------------------------------------------------
// Overloaded operators
//--------------------------------------------------------------------
	void operator=(d_vector &source);
	void operator*=(double multiplier);
	void operator+=(double delta);
	bool operator==(d_vector &vector2);
	operator double*(void); // returns array which must be freed by caller

//--------------------------------------------------------------------
// Property get and set functions
//--------------------------------------------------------------------
	WORD GetElts(void);
	double GetElement(WORD elt);
	bool SetElement(WORD elt, double value);

//--------------------------------------------------------------------
// Vector functions
//--------------------------------------------------------------------
	void SetToZero(void);
	void SetToValue(double value); // sets whole matrix to this value
	bool SwapElements(WORD elt_1, WORD elt_2);

//--------------------------------------------------------------------
// Misc. functions
//--------------------------------------------------------------------
	void Free();
	void Initialise(WORD elements);
	void Initialise(WORD elements, double *init_data);
	void Set(WORD elements, double *input_data);

	double *data;
private:
	void init(void);
	bool allocate(void);
	void free(void);

	WORD n_elements;
};
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
class d_matrix
{
	friend d_vector;
public:
//--------------------------------------------------------------------
// constructors
//--------------------------------------------------------------------
	d_matrix();
	d_matrix(WORD rows, WORD columns);
	d_matrix(WORD rows, WORD columns, double *init_data);
	d_matrix(d_matrix &source);

//--------------------------------------------------------------------
// destructor
//--------------------------------------------------------------------
	~d_matrix();

//--------------------------------------------------------------------
// Overloaded operators
//--------------------------------------------------------------------
	void operator=(d_matrix &source);
	void operator*=(double multiplier);
	void operator+=(double delta);
	bool operator==(d_matrix &matrix2);
	operator double*(void); // returns row-by-row array which must be freed by caller

//--------------------------------------------------------------------
// Property get and set functions
//--------------------------------------------------------------------
	WORD GetRows(void);
	WORD GetColumns(void);
	double GetElement(WORD row, WORD column);
	double GetElement(DWORD offset);
	bool SetElement(WORD row, WORD column, double value);
	bool SetElement(DWORD offset, double value);

//--------------------------------------------------------------------
// Matrix functions
//--------------------------------------------------------------------
	void SetToZero(void);
	void SetToValue(double value); // sets whole matrix to this value
	void Set(WORD rows, WORD columns, double *input_data);
	void SetDiagonal(double value);
	void SetLowerToUpper(void);
	bool SetToIdentity(void); // only if square
	bool IsSymetric(void);
	bool IsSquare(void);
	bool Transpose(void); // only if square
	bool Transpose(d_matrix &source); // (re)create as transpose of source
	bool Mult(d_matrix &mat1, d_matrix &mat2);
	bool SwapColumns(WORD col_1, WORD col_2);
	bool SwapRows(WORD row_1, WORD row_2);
	bool GetEigenvectors(d_matrix &Evecs, d_vector &Evals);
	bool InsertRow(d_vector &new_row, short position);
	bool InsertColumn(d_vector &new_column, short position);
	bool MultRow(short row, double multiplier);
	bool MultColumn(short col, double multiplier);
	bool CopyRow(short from_row, short to_row);
	bool InsertInRow(short row, short row_offset, double value);

//--------------------------------------------------------------------
// Misc. functions
//--------------------------------------------------------------------
	void Free(void);
	void Initialise(WORD rows, WORD columns);
	void Initialise(WORD rows, WORD columns, double *init_data);

	double *data;
	double **row_vec;

private:
	short JacobiCalc(d_vector &Evals, d_matrix &Evecs, int &n_rotations);

	DWORD n_elements;
	WORD n_columns;
	WORD n_rows;

	void init(void);
	bool allocate(void);
	bool is_square;
};

