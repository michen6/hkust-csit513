//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
#ifndef _BACKGROUND_H
#define _BACKGROUND_H

enum {TASK_PENDING = 0, TASK_CURRENT = 1, TASK_READY = 2, TASK_UNCLAIMED = 4, TASK_COMPLETE = 8};


typedef struct tag_task
{
	tag_task *prev;		// prev task, NULL if this is top
	tag_task *next;		// next task, NULL if this is last
	long start_clock;	// set by TaskList
	long end_clock;		// set by TaskList
	bool break_task;	// if true, processing of this task should end
	short status;		// TASK_NIL, TASK_PENDING, TASK_CURRENT, TASK_DONE
	char *caller_name;	// dll-internal Excel name of caller
	bool (* fn_ptr)(tag_task *);	// passed in function ptr
	xloper fn_ret_val;	// used for intermediate and final value
	int num_args;
	xloper arg_array[1]; // 1st in array of args for this task
}
	task;


class TaskList
{
public:
	TaskList(int (__stdcall * Cmd)(void), short FreqSecs, int (__stdcall * MenuFn)(void));
	~TaskList(void);

// Thread management functions

// These two functions only need to be called only once
	bool CreateTaskThread(void);
	void DeleteTaskThread(void);

	bool IsThreadCreated(void) {return m_ThreadIsCreated;};
	bool IsThreadRunning(void) {return m_ThreadIsRunning;};
	DWORD GetThreadId(void) {return m_ThreadID;};

	long GetThreadSleepMs(void) {return m_ThreadSleepMs;};
	short GetPollingSecs(void) {return m_PollingCmdFreqSecs;};
	bool SetThreadSleepMs(long sleep_ms);
	bool SetPollingSecs(short rpt_secs);

// These two functions are used to control the execution of tasks
	bool ResumeTaskThread(void);
	bool SuspendTaskThread(void);

	bool TaskThreadIsActive(void) {return m_ThreadIsCreated && m_ThreadIsRunning;};

	DWORD TaskThreadMain(void);

// Task management functions
	xloper UpdateTask(bool (* fn_ptr)(tag_task *), xloper *arg_array, short num_args);
	bool SetDoneTasks(void);
	void DeleteUnclaimedTasks(void);
	void GetTaskStats(long &pending, long &done);

private:
// Thread management functions
	void StopTaskThread(void);

// Task management functions
	void AddTaskToListTail(task *p);
	bool RemoveTaskFromList(task *p);
	void DeleteTask(task *p);
	void BreakCurrentTask(task *p);

	void ModifyTask(task *p, xloper *arg_array, short num_args);

	void GetNextTask(void);		// background: used to set pCurrent
	bool AddNewTask(bool (* fn_ptr)(tag_task *), xloper *arg_array, short num_args); //, cpp_xloper &Caller);
	task *FindTask(char *name); // get ptr to the task associated with 'name'
	bool ArgsChanged(task *p, xloper *arg_array, short num_args);

	void ReleaseTask(task *pTask);
	void DeleteAllTasks(void);

	CRITICAL_SECTION m_ThreadControl;
	HANDLE m_ThreadHandle;
	DWORD m_ThreadID;
	long m_ThreadSleepMs;
	bool m_ThreadIsCreated;	// modified by foreground thread
	bool m_ThreadIsRunning;	// modified by both threads
	bool m_ThreadExitFlagSet;	// modified by foreground thread
	bool m_SuspendAllFlagSet;	// modified by foreground thread

	CRITICAL_SECTION m_ListControl;
	task *m_pHead; // head of task list
	task *m_pTail; // tail of task list, new tasks placed after this
	task *m_pCurrent; // pointer to task currently being processed

	int (__stdcall * PollingCmd)(void);
	int (__stdcall * MenuSetupFn)(void);
	short m_PollingCmdFreqSecs;

public:
	bool m_BreakPollingCmdFlag;
};

extern TaskList ExampleTaskList;

#endif // _BACKGROUND_H