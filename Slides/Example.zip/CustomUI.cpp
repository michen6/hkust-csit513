//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains examples relating to the addition and removal of
// a custom menus and event traps, the display of custom dialogs and the
// running of regularly-repeating timed commands.
//============================================================================
//============================================================================
#include <windows.h>
#include "XllAddIn.h"
#include "XllNames.h"

//========================================================================
// This function is called from xlAutoOpen and xlAutoClose.
// Depending on the value of set_up, it creates or deletes custom menus,
// event traps, etc.
//========================================================================

#define NUM_MENU_ITEMS	10


void customise_Excel_UI(bool set_up)
{
	char *menu_txt[NUM_MENU_ITEMS * 2] =
	{
		"&XLL Example",		"",
		"&Define name",		"DefineNewName",	// code: define_new_name
		"&CleanNameList",	"CleanNameList",	// code: clean_xll_name_list
		"XLL Call &Version","XLCallVersion",	// code: xl_call_version
		"-",				"",
		"OnTi&me example",	"OnTimeExample",	// code: on_time_example_cmd
		"Example Dialo&g",	"ShowExampleDialog",// code: show_example_dialog
		"Get &Username",	"GetUsername",		// code: get_username
		"-",				"",
		"Set TestRange values","SetValues",		// code: set_values (Section 8.7)
	};
	cpp_xloper MenuRef((WORD)NUM_MENU_ITEMS, (WORD)2, menu_txt); // 2 columns
	cpp_xloper BarNum(10); // the worksheet menu bar
	cpp_xloper RetVal;
	cpp_xloper Menu;
	int xl4;

//----------------------------------------------------------------
// Example menu: "&XLL Example"
//----------------------------------------------------------------
	if(set_up)
	{
		xl4 = Excel4(xlfAddMenu, &RetVal, 2, &BarNum, &MenuRef);
	}
	else
	{			
		Menu = "&XLL Example";
		Excel4(xlfDeleteMenu, &RetVal, 2, &BarNum, &Menu);
	}
	RetVal.Free(true);
//----------------------------------------------------------------
// Set up a sub-menu on the Data menu
//----------------------------------------------------------------
	Menu = "Data";
	cpp_xloper Cmd("&XLL Example");
	cpp_xloper SubMenuPos(0);

	if(set_up)
	{
		xl4 = Excel4(xlfAddMenu, &RetVal, 4, &BarNum, &MenuRef, &Menu, &SubMenuPos);
	}
	else
	{
		Excel4(xlfDeleteCommand, &RetVal, 3, &BarNum, &Menu, &Cmd);
	}
	RetVal.Free(true);
//----------------------------------------------------------------
// Set up a example menu item at the bottom of the Tools menu
//----------------------------------------------------------------
	Menu = "Tools";
	cpp_xloper CmdRef((WORD)1, (WORD)2, menu_txt + 2); // 1 row, 2 columns
	Cmd = menu_txt[2];

	if(set_up)
	{
		xl4 = Excel4(xlfAddCommand, &RetVal, 3, &BarNum, &Menu, &CmdRef);
	}
	else
	{
		Excel4(xlfDeleteCommand, &RetVal, 3, &BarNum, &Menu, &Cmd);
	}
	RetVal.Free(true);
//----------------------------------------------------------------
// Set up a example menu item before the 1st sperarator of the Tools menu
//----------------------------------------------------------------

	if(set_up)
	{
		Cmd = "-";
		xl4 = Excel4(xlfAddCommand, &RetVal, 4, &BarNum, &Menu, &CmdRef, &Cmd);
	}
	else
	{
		Excel4(xlfDeleteCommand, &RetVal, 3, &BarNum, &Menu, &Cmd);
	}
	RetVal.Free(true);
//----------------------------------------------------------------
// Set up a example menu item before the 1st sperarator of the Tools menu
//----------------------------------------------------------------

	if(set_up)
	{
		Cmd = "Macro";
		xl4 = Excel4(xlfAddCommand, &RetVal, 5, &BarNum, &Menu, &CmdRef, &Cmd, &SubMenuPos);
	}
	else
	{
		Excel4(xlfDeleteCommand, &RetVal, 3, &BarNum, &Menu, &Cmd);		
	}
	RetVal.Free(true);
//----------------------------------------------------------------
// Set up an example menu item on the worksheet short menu
//----------------------------------------------------------------

	BarNum = 7; // indicates shortcut menu
	Menu = 4; // indicates worksheet cells menu

	if(set_up)
	{
		xl4 = Excel4(xlfAddCommand, &RetVal, 3, &BarNum, &Menu, &CmdRef);
	}
	else
	{
		Excel4(xlfDeleteCommand, &RetVal, 3, &BarNum, &Menu, &Cmd);		
	}
	RetVal.Free(true);

//----------------------------------------------------------------
// Set up an example keyboard trap for Ctrl-l
//----------------------------------------------------------------

	cpp_xloper Keys("^+l");

	if(set_up)
	{
		Cmd = "XLL_CMD2";
		xl4 = Excel4(xlcOnKey, &RetVal, 2, &Keys, &Cmd);
	}
	else
	{
		xl4 = Excel4(xlcOnKey, &RetVal, 1, &Keys);
	}
	RetVal.Free(true);
}
//=================================================================


//=================================================================
#define SECS_PER_DAY		(60.0 * 60.0 * 24.0)

bool on_time_example_running = false;

int __stdcall increment_counter(void)
{
	if(!on_time_example_running)
		return 0;

	xlName Counter("!Counter");

	++Counter; // Does nothing if Counter not defined

// Schedule the next call to this command in 10 seconds' time
	cpp_xloper Now;
	Excel4(xlfNow, &Now, 0);
	cpp_xloper ExecTime((double)Now + 10.0 / SECS_PER_DAY);
	cpp_xloper CmdName("IncrementCounter");
	cpp_xloper RetVal;

	int xl4 = Excel4(xlcOnTime, &RetVal, 2, &ExecTime, &CmdName);
	return 1;
}
//------------------------------------------------------------------------
// This command is executed from the XLL Example menu and toggles its
// own check mark which reflects the state of bool on_time_example_running.
// If on_time_example_running==true after toggle, calls the command increment_counter
// that increments a counter and sets itself to be run again and again after
// a hard-coded (in this case) delay.  Otherwise, on_time_example_running==false
// causes the next execution of increment_counter to be the last.
//------------------------------------------------------------------------
int __stdcall on_time_example_cmd(void)
{
// Toggle the module-scope boolean flag and, if now true, start the
// first of the repeated calls to increment_counter()
	if(on_time_example_running = !on_time_example_running)
		increment_counter();

	cpp_xloper BarNum(10); // the worksheet menu bar
	cpp_xloper Menu("&XLL Example");
	cpp_xloper Cmd("OnT&ime example");
	cpp_xloper Status(on_time_example_running);
	Excel4(xlfCheckCommand, 0, 4, &BarNum, &Menu, &Cmd, &Status);
	return 1;
}
//========================================================================



//=================================================================
#define NUM_EXAMPLE_DIALOG_ROWS		40

cpp_xloper ExampleDlg[NUM_EXAMPLE_DIALOG_ROWS * CAPI_DLG_COLUMNS] =
{
	"", "", "", 720, 470, "Example dialog", "", // Dialog box size and title
	1, 395, 440, 90, "", "OK", "", // OK (default)
	2, 495, 440, 90, "", "Cancel", "", // Cancel button
	3, 595, 440, 110, "", "Other button", "", // Alt. OK button
	5, 40, 10, "", "", "This is an example custom dialog box that demonstrates the various XLM C-API dialog elements.", "", // Text
	14, 40, 35, 290, 125, "Group box 1", "", // Group box
	5, 50, 53, "", "", "Text box", "", // Text
	6, 150, 50, "", "", "", "Default", // Text box
	5, 50, 73, "", "", "Integer box", "", // Text
	7, 150, 70, "", "", "", 1, // Integer box
	5, 50, 93, "", "", "Floating pt box", "", // Text
	8, 150, 90, "", "", "", 3.456, // Floating pt box
	5, 50, 113, "", "", "Formula box", "", // Text
	9, 150, 110, "", "", "", "=SUM(R1C1:R35C1)", // Formula edit box
	5, 50, 133, "", "", "Reference box", "", // Text
	10, 150, 130, "", "", "", "R34C19", // Ref edit box
	11, 40, 160, 340, 38, "Radio group", 1, // Radio button group
	112, 65, 172, "", "", "No. 1", "", // Radio button
	212, 165, 172, "", "", "No. 2", "", // Radio button
	12, 265, 172, "", "", "No. 3", "", // Radio button
	14, 340, 35, 350, 125, "Group box 2", "", // Group box
	13, 540, 65, "", "", "Checkbox &1", 1, // Check box
	13, 540, 80, "", "", "Checkbox &2", false, // Check box
	213, 540, 95, "", "", "Checkbox &3", true, // Check box
	5, 360, 50, "", "", "List box", "", // Text
	15, 360, 65, 150, 60, "{123.456,1,2,3}", 2, // List box
	14, 40, 200, 340, 110, "", "", // Group box
	5, 50, 218, "", "", "Linked list", "", // Text
	6, 150, 215, "", "", "", "3", // Text box
	16, 150, 235, "", 60, "{123.456,1,2,3}", 4, // Linked list box
	5, 50, 323, "", "", "Linked file list", "", // Text
	6, 150, 320, "", "", "", "*.*", // Text box
	18, 150, 338, "", "", "", "", // Linked file box
	19, 325, 338, "", "", "", "", // Linked path box
	20, 325, 323, "", "", "", "", // Directory box
	5, 400, 173, "", "", "Drop down list", "", // Text
	21, 520, 170, "", "", "{123.456,1,2,3}", 1, // Drop down list
	5, 400, 193, "", "", "Drop down combo", "", // Text
	6, 520, 190, "", "", "", "123.456", // Text box
	22, "", "", "", "", "{123.456,1,2,3}", 1, // Drop down combo
};

//------------------------------------------------------------------------
int __stdcall show_example_dialog(void)
{
	xloper ret_val;
	int xl4;

	cpp_xloper DialogDef((WORD)NUM_EXAMPLE_DIALOG_ROWS, (WORD)CAPI_DLG_COLUMNS, ExampleDlg);

	do
	{
		xl4 = Excel4(xlfDialogBox, &ret_val, 1, &DialogDef);

		if(xl4 || (ret_val.xltype == xltypeBool && ret_val.val._bool == 0))
			break;

		Excel4(xlFree, 0, 1, &ret_val);
	}
	while(1);

	Excel4(xlFree, 0, 1, &ret_val);
	return 1;
}

//------------------------------------------------------------------------
#define NUM_USERNAME_DIALOG_ROWS		10

cpp_xloper UsernameDlg[NUM_USERNAME_DIALOG_ROWS * CAPI_DLG_COLUMNS] =
{
	"", "", "", 372, 200, "Example dialog", "", // Dialog box size
	1, 100, 170, 90, "", "OK", "", // Default OK button
	2, 200, 170, 90, "", "Cancel", "", // Cancel button
	5, 40, 10, "", "", "Please enter your username and password.", "", // Text
	14, 40, 35, 290, 100, "", "", // Group box
	5, 50, 53, "", "", "Username", "", // Text
	6, 150, 50, "", "", "", "MyName", // Text edit box
	5, 50, 73, "", "", "Password", "", // Text
	6, 150, 70, "", "", "", "********", // Text edit box
	13, 50, 110, "", "", "Remember username and password", true, // Checkbox
};

//------------------------------------------------------------------------
int __stdcall get_username(void)
{
	xloper ret_val;
	int xl4;

	cpp_xloper DialogDef((WORD)NUM_USERNAME_DIALOG_ROWS, (WORD)CAPI_DLG_COLUMNS, UsernameDlg);

	do
	{
		xl4 = Excel4(xlfDialogBox, &ret_val, 1, &DialogDef);

		if(xl4 || (ret_val.xltype == xltypeBool && ret_val.val._bool == 0))
			break;

// Process the input from the dialog by reading
// the 7th column of the returned array.

// ... code omitted

		Excel4(xlFree, 0, 1, &ret_val);
	}
	while(1);
	Excel4(xlFree, 0, 1, &ret_val);
	return 1;
}
//=================================================================

//==========================================================
int __stdcall menu_item_type(int bar_ID, xloper *pMenu, int position)
{
	if(position <= 0)
		return -1;

	cpp_xloper BarID(bar_ID);
	cpp_xloper Pos(position);
	cpp_xloper RetVal;
	int xl4 = Excel4(xlfGetBar, &RetVal, 3, p_xlNil, p_xlNil, p_xlNil);

// Check that bar_ID and menu are valid by asking for the
// text of the menu at position menu_num
//	if((xl4 = Excel4(xlfGetBar, &RetVal, 3, &BarID, p_xlMissing, p_xlMissing))
//	if((xl4 = Excel4(xlfGetBar, &RetVal, 2, &BarID, pMenu))
//	if((xl4 = Excel4(xlfGetBar, &RetVal, 1, &BarID))
	if(xl4 || !RetVal.IsType(xltypeStr))
		return -1;

// Get Excel to free the memory before re-use
	RetVal.Free(true);

// Get the text of the menu item at the given position
	Pos = position;

	if(Excel4(xlfGetBar, &RetVal, 3, &BarID, pMenu, &Pos)
	|| !RetVal.IsType(xltypeStr))
		return 0;

// Is it a separator line?
	char *p = (char *)RetVal;
	bool is_separator = (*p == '-');
	free(p);
	RetVal.Free(true);

	if(is_separator)
		return 2;

// Is it a command?  Try and get the text of the 1st sub-menu item
	cpp_xloper SubCmd(1);

	if(Excel4(xlfGetBar, &RetVal, 4, &BarID, pMenu, &Pos, &SubCmd)
	|| !RetVal.IsType(xltypeStr))
	{
	// It's a command
		return 1;
	}
	RetVal.SetExceltoFree();

// It's a sub-menu
	return 3;
}
