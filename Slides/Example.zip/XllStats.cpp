//============================================================================
//============================================================================
//
// Excel Add-in Development in C/C++, Applications in Finance
// 
// Author: Steve Dalton
// 
// Published by John Wiley & Sons Ltd, The Atrium, Southern Gate, Chichester,
// West Sussex, PO19 8SQ, UK.
// 
// All intellectual property rights and copyright in the code listed in this
// module are reserved.  You may reproduce and use this code only as permitted
// in the Rules of Use that you agreed to on installation.  To use the material
// in this source module, or material derived from it, in any other way you
// must first obtain written permission.  Requests for permission can be sent
// by email to permissions@eigensys.com.
// 
// No warranty, explicit or implied, is made by either the author or publisher
// as to the quality, fitness for a particular purpose, accuracy or
// appropriateness of material in this module.  The code and methods contained
// are intended soley for example and clarification.  You should not rely on
// any part of this code without having completely satisfied yourself that it
// is correct and appropriate for your needs.
//
//============================================================================
//============================================================================
// This source file contains functions that calculate the cumulative normal
// distribution and its inverse and that calculate random samples from this
// distribution using the Box-Muller transformation.
//============================================================================
//============================================================================
#include <windows.h>
#include <math.h>

#include "XllAddIn.h"

#define TWO_PI		6.28318530717959

//==============================================================
void __stdcall nsample_BM_pair(xl_array *p_array)
{
//	Max array_size is 0x1000000 = 256 ^ 3
	long array_size = p_array->columns * p_array->rows;

	if(array_size == 2)
	{
		double r1 = p_array->array[0];
		double r2 = p_array->array[1];

		if(r1 > 0.0 && r1 <= 1.0 && r2 > 0.0 && r2 <= 1.0)
		{
			r1 = sqrt(-2.0 * log(r1));
			r2 *= TWO_PI;
			p_array->array[0] = r1 * cos(r2);
			p_array->array[1] = r1 * sin(r2);
			return;
		}
	}
	memset(p_array->array, 0, array_size * sizeof(double));
}
//==============================================================
double __stdcall nsample_BM(void)
{
	static double sample_zero;
	static bool loaded = false;

	if(loaded)
	{
		loaded = false;
		return sample_zero;
	}

	loaded = true;

	xloper ret_val;

	Excel4(xlfRand, &ret_val, 0);
	double r1 = ret_val.val.num;

	Excel4(xlfRand, &ret_val, 0);
	double r2 = ret_val.val.num;

	r1 = sqrt(-2.0 * log(r1));
	r2 *= TWO_PI;

	sample_zero = r1 * cos(r2);
	return r1 * sin(r2);
}
//=======================================================================
// Numerical approximation to the cumulative normal dsitribution
//=======================================================================
// double cndist(double d)
//
// See Abramowitz & Stegun 26.2.17  |error| < 7.5e-8 
//=======================================================================

#define B1			0.31938153
#define B2			-0.356563782
#define B3			1.781477937
#define B4			-1.821255978
#define B5			1.330274429
#define PP			0.2316419
#define ROOT_2PI	2.506628274631

//=======================================================================
double cndist(double d)
{
	if(d == 0.0) return 0.5;
	double t = 1.0 / (1.0 + PP * fabs(d));
	double e = exp(-0.5 * d * d) / ROOT_2PI;
	double n = ((((B5 * t + B4) * t + B3) * t + B2) * t + B1) * t;
	return (d > 0.0) ? 1.0 - e * n : e * n;
}
//=======================================================================
#define MAX_CNDIST_ITERS	500
//
// Calculates cumulative normal distribution to highest accuracy
// supported using Taylor series and...
//
//=======================================================================
double cndist_taylor(double d, int &iterations)
{
	if(fabs(d) > 6.0)
	{
// Small difference between the cndist() approximation and the real
// thing in the tails, although this might upset some pdf functions,
// where kinks in the gradient create large jumps in the pdf
		iterations = 0;
		return cndist(d);
	}

	double d2 = d * d;
	double last_sum = 0, sum = 1.0;
	double factor = 1.0;
	double k2;

	int k;
	for(k = 1; k <= MAX_CNDIST_ITERS; k++)
	{
		k2 = k << 1;
		sum += (factor *= d2 * (1.0 - k2) / k2 / (k2 + 1.0));

		if(last_sum == sum)
			break;

		last_sum = sum;
	}
	iterations = k;
	return 0.5 + sum * d / ROOT_2PI;
}
//=====================================================================
// Excel add-in interface functions
//=====================================================================
xloper * __stdcall ndist_taylor(double d)
{
	double retvals[2];
	int iterations;

	retvals[0] = cndist_taylor(d, iterations);
	retvals[1] = iterations;

	cpp_xloper RetVal((WORD)1, (WORD)2, retvals);
	return RetVal.ExtractXloper();
}
//=====================================================================
double __stdcall norm_dist(double d, xloper *p_use_taylor)
{
	bool use_taylor = (p_use_taylor->xltype == xltypeBool && p_use_taylor->val._bool == 1);
	int iterations;

	if(use_taylor)
		return cndist_taylor(d, iterations);
	else
		return cndist(d);
}
//=====================================================================
#define NDINV_ITER_LIMIT		50
#define NDINV_EPSILON			1e-12 // How precise do we want to be
#define NDINV_FIRST_NUDGE		1e-7

// How much change in answer from one iteration to the next
#define NDINV_DELTA				1e-10

// Approximate working limits of Excel's NORMSINV() function in Excel 2000
#define NORMSINV_LOWER_LIMIT	3.024e-7
#define NORMSINV_UPPER_LIMIT	0.999999

//=====================================================================
xloper * __stdcall norm_dist_inv(double prob, xloper *p_use_taylor)
{
	if(prob <= 0.0 || prob >= 1.0)
		return p_xlErrNum;

	bool use_taylor = (p_use_taylor->xltype == xltypeBool && p_use_taylor->val._bool == 1);
	int iterations;

// Get a (pretty) good first approximation using Excel's NORMSINV()
// worksheet function. First check that prob is within NORMSINV's
// working limits

	static xloper op_ret_val;
	double v1, v2, p1, p2, pdiff, temp;

	op_ret_val.xltype = xltypeNum;

	if(prob < NORMSINV_LOWER_LIMIT)
	{
		v2 = (v1 = -5.0) - NDINV_FIRST_NUDGE;
	}
	else if(prob > NORMSINV_UPPER_LIMIT)
	{
		v2 = (v1 = 5.0) + NDINV_FIRST_NUDGE;
	}
	else
	{
		op_ret_val.val.num = prob;

		Excel4(xlfNormsinv, &op_ret_val, 1, &op_ret_val);

		if(op_ret_val.xltype != xltypeNum)
			return p_xlErrNum; // shouldn't need this here

		v2 = op_ret_val.val.num;
		v1 = v2 - NDINV_FIRST_NUDGE;
	}

// Use a secant method to make the result consistent with the
// specified cndist() function

	if(use_taylor)
		p2 = cndist_taylor(v2, iterations) - prob;
	else
		p2 = cndist(v2) - prob;

	if(fabs(p2) <= NDINV_EPSILON)
	{
		op_ret_val.val.num = v2;
		return &op_ret_val; // already close enough
	}

	if(use_taylor)
		p1 = cndist_taylor(v1, iterations) - prob;
	else
		p1 = cndist(v1) - prob;

	for(short i = NDINV_ITER_LIMIT; --i;)
	{
		if(fabs(p1) <= NDINV_EPSILON || (pdiff = p2 - p1) == 0.0)
		{
// Result is close enough, or need to avoid divide by zero
			op_ret_val.val.num = v1;
			return &op_ret_val;  
		}

		temp = v1;
		v1 = (v1 * p2 - v2 * p1) / pdiff;

		if(fabs(v1 - temp) <= NDINV_DELTA) // not much improvement
		{
			op_ret_val.val.num = v1;
			return &op_ret_val;
		}
		v2 = temp;
		p2 = p1;

		if(use_taylor)
			p1 = cndist_taylor(v1, iterations) - prob;
		else
			p1 = cndist(v1) - prob;
	}
	return p_xlErrValue;
}
